﻿using IL2CPP_Core.Objects;
using System;
using System.Runtime.InteropServices;

namespace SDK
{
    unsafe public class IL2Patch : IL2Object
    {
        internal IL2Method TargetMethod;
        internal IntPtr OriginalMethod;
        internal IL2Patch(IL2Method targetMethod, Delegate newMethod) : base(IntPtr.Zero)
        {
            Pointer = newMethod.Method.MethodHandle.GetFunctionPointer();
            TargetMethod = targetMethod;
            MinHook.MinHook.VRC_CreateHook(*(IntPtr*)targetMethod.Pointer, Pointer, out OriginalMethod);
            Enabled = true;
        }
        internal IL2Patch(IntPtr targetMethod, Delegate newMethod) : base(IntPtr.Zero)
        {
            Pointer = newMethod.Method.MethodHandle.GetFunctionPointer();
            TargetMethod = new IL2Method(targetMethod);

            MinHook.MinHook.VRC_CreateHook(targetMethod, Pointer, out OriginalMethod);
            Enabled = true;
        }

        public T CreateDelegate<T>() where T : Delegate
        {
            return Marshal.GetDelegateForFunctionPointer(OriginalMethod, typeof(T)) as T;
        }


        public bool Enabled
        {
            get => isEnabled;
            set
            {
                if (isEnabled = value)
                    MinHook.MinHook.VRC_EnableHook(*(IntPtr*)TargetMethod.Pointer);
                else
                    MinHook.MinHook.VRC_DisableHook(*(IntPtr*)TargetMethod.Pointer);
            }
        }

        private bool isEnabled = true;
    }
}
