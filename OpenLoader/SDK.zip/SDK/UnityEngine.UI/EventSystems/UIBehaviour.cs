﻿using System;
using IL2CPP_Core.Objects;

namespace UnityEngine.EventSystems
{
    public abstract class UIBehaviour : MonoBehaviour
    {
        public UIBehaviour(IntPtr ptr) : base(ptr)
        {
        }

        protected UIBehaviour() : base(IntPtr.Zero)
        {
            this.Pointer = Import.Object.il2cpp_object_new(Instance_Class.Pointer);
            Instance_Class.GetMethod(".ctor").Invoke(this.Pointer, true);
        }

        protected virtual void Awake()
        {
            Instance_Class.GetMethod("Awake").Invoke(this, true);
        }

        protected virtual void OnEnable()
        {
            Instance_Class.GetMethod("OnEnable").Invoke(this, true);
        }

        protected virtual void Start()
        {
            Instance_Class.GetMethod("Start").Invoke(this, true);
        }

        protected virtual void OnDisable()
        {
            Instance_Class.GetMethod("OnDisable").Invoke(this, true);
        }

        protected virtual void OnDestroy()
        {
            Instance_Class.GetMethod("OnDestroy").Invoke(this, true);
        }

        public virtual bool IsActive()
        {
            return Instance_Class.GetMethod("IsActive").Invoke<bool>(this, true).GetValue();
        }

        protected virtual void OnRectTransformDimensionsChange()
        {
            Instance_Class.GetMethod("OnRectTransformDimensionsChange").Invoke(this, true);
        }

        protected virtual void OnBeforeTransformParentChanged()
        {
            Instance_Class.GetMethod("OnBeforeTransformParentChanged").Invoke(this, true);
        }

        protected virtual void OnTransformParentChanged()
        {
            Instance_Class.GetMethod("OnTransformParentChanged").Invoke(this, true);
        }

        protected virtual void OnDidApplyAnimationProperties()
        {
            Instance_Class.GetMethod("OnDidApplyAnimationProperties").Invoke(this, true);
        }

        protected virtual void OnCanvasGroupChanged()
        {
            Instance_Class.GetMethod("OnCanvasGroupChanged").Invoke(this, true);
        }

        protected virtual void OnCanvasHierarchyChanged()
        {
            Instance_Class.GetMethod("OnCanvasHierarchyChanged").Invoke(this, true);
        }

        public bool IsDestroyed()
        {
            return Instance_Class.GetMethod("IsDestroyed").Invoke<bool>(this, true).GetValue();
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.UI"].GetClass("UIBehaviour", "UnityEngine.EventSystems");
    }
}
