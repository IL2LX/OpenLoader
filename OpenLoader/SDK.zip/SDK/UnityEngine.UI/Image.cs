﻿using System;
using IL2CPP_Core.Objects;

namespace UnityEngine.UI
{
    public class Image : Graphic
    {
        public Image(IntPtr ptr) : base(ptr)
        {
        }

        public Sprite sprite
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("sprite").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<Sprite>();
            }
            set
            {
                Instance_Class.GetProperty("sprite").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    (value == null) ? IntPtr.Zero : value.Pointer
                }, true);
            }
        }

        public Sprite overrideSprite
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("overrideSprite").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<Sprite>();
            }
            set
            {
                Instance_Class.GetProperty("overrideSprite").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    (value == null) ? IntPtr.Zero : value.Pointer
                }, true);
            }
        }

        public Material material
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("material").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<Material>();
            }
            set
            {
                Instance_Class.GetProperty("material").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    (value == null) ? IntPtr.Zero : value.Pointer
                }, true);
            }
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.UI"].GetClass("Image", "UnityEngine.UI");
    }
}
