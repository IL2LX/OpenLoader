﻿using IL2CPP_Core.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDK.UnityEngine.UI
{
    public class MaskableGraphic
    {
        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.UI"].GetClass(nameof(MaskableGraphic), "UnityEngine.UI");
    }
}
