﻿using System;
using IL2CPP_Core.Objects;
using UnityEngine.EventSystems;

namespace UnityEngine.UI
{
    public class Graphic : UIBehaviour
    {
        public Graphic(IntPtr ptr) : base(ptr)
        {
        }

        public unsafe Color color
        {
            get
            {
                return Instance_Class.GetProperty("color").GetGetMethod().Invoke<Color>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("color").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.UI"].GetClass("Graphic", "UnityEngine.UI");
    }
}
