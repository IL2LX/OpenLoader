﻿using System;
using IL2CPP_Core.Objects;

namespace UnityEngine
{
    public static class Physics
    {
        public unsafe static Vector3 gravity
        {
            get
            {
                return Instance_Class.GetProperty("gravity").GetGetMethod().Invoke<Vector3>().GetValue();
            }
            set
            {
                Instance_Class.GetProperty("gravity").GetSetMethod().Invoke(new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                });
            }
        }

        public unsafe static bool Raycast(Ray ray, out RaycastHit hitInfo)
        {
            IL2Method method = Instance_Class.GetMethod("Raycast", (IL2Method x) => x.GetParameters().Length == 2 && x.GetParameters()[1].Name == "hitInfo");
            fixed (RaycastHit* ptr = &hitInfo)
            {
                RaycastHit* value = ptr;
                return method.Invoke<bool>(new IntPtr[]
                {
                    new IntPtr((void*)(&ray)),
                    new IntPtr((void*)value)
                }).GetValue();
            }
        }

        public static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.PhysicsModule"].GetClass("Physics", "UnityEngine");
    }
}
