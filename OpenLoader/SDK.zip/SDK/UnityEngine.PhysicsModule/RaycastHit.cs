﻿namespace UnityEngine
{
    public struct RaycastHit
    {
        public Vector3 point
        {
            get
            {
                return this.m_Point;
            }
            set
            {
                this.m_Point = value;
            }
        }

        public Vector3 normal
        {
            get
            {
                return this.m_Normal;
            }
            set
            {
                this.m_Normal = value;
            }
        }

        public Vector3 barycentricCoordinate
        {
            get
            {
                return new Vector3(1f - (this.m_UV.y + this.m_UV.x), this.m_UV.x, this.m_UV.y);
            }
            set
            {
                this.m_UV = value;
            }
        }

        public float distance
        {
            get
            {
                return this.m_Distance;
            }
            set
            {
                this.m_Distance = value;
            }
        }

        public int triangleIndex
        {
            get
            {
                return this.m_FaceID;
            }
        }

        public Collider collider
        {
            get
            {
                Object @object = Object.FindObjectFromInstanceID(this.m_Collider);
                if (!(@object != null))
                {
                    return null;
                }
                return @object.GetValue<Collider>();
            }
        }

        public Transform transform
        {
            get
            {
                return this.collider.transform;
            }
        }


        private Vector3 m_Point;

        private Vector3 m_Normal;

        private int m_FaceID;

        private float m_Distance;

        private Vector2 m_UV;

        private int m_Collider;
    }
}
