﻿using System;
using IL2CPP_Core.Objects;

namespace UnityEngine
{
    public class AssetBundle : Object
    {
        public AssetBundle(IntPtr ptr) : base(ptr)
        {
        }

        internal unsafe static AssetBundle LoadFromFile_Internal(string path, uint crc, ulong offset)
        {
            IL2Object il2Object = Instance_Class.GetMethod("LoadFromFile_Internal").Invoke(new IntPtr[]
            {
                new IL2String_utf8(path).Pointer,
                new IntPtr((void*)(&crc)),
                new IntPtr((void*)(&offset))
            });
            if (il2Object == null)
            {
                return null;
            }
            return il2Object.GetValue<AssetBundle>();
        }

        public static AssetBundle LoadFromFile(string path)
        {
            IL2Object il2Object = Instance_Class.GetMethod("LoadFromFile").Invoke(new IntPtr[]
            {
                new IL2String_utf8(path).Pointer
            });
            if (il2Object == null)
            {
                return null;
            }
            return il2Object.GetValue<AssetBundle>();
        }

        public bool isStreamedSceneAssetBundle
        {
            get
            {
                return Instance_Class.GetProperty("isStreamedSceneAssetBundle").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public Object LoadAsset(string name)
        {
            IL2Object il2Object = Instance_Class.GetMethod("LoadAsset", (IL2Method x) => x.ReturnType.Name == Object.Instance_Class.FullName && x.GetParameters().Length == 1).Invoke(this, new IntPtr[]
            {
                new IL2String_utf8(name).Pointer
            }, true);
            if (il2Object == null)
            {
                return null;
            }
            return il2Object.GetValue<AssetBundle>();
        }

        public T LoadAsset<T>(string name) where T : Object
        {
            Object @object = this.LoadAsset(name);
            if (@object == null)
            {
                return default(T);
            }
            return @object.GetValue<T>();
        }

        public unsafe void Unload(bool unloadAllLoadedObjects)
        {
            Instance_Class.GetMethod("Unload").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&unloadAllLoadedObjects))
            }, true);
        }

        public string[] GetAllAssetNames()
        {
            IL2Object il2Object = Instance_Class.GetMethod("GetAllAssetNames").Invoke(this, true);
            if (il2Object == null)
            {
                return null;
            }
            IntPtr[] array = new IL2Array<IntPtr>(il2Object.Pointer).ToArray();
            int num = array.Length;
            string[] array2 = new string[num];
            for (int i = 0; i < num; i++)
            {
                array2[i] = new IL2String(array[i]).ToString();
            }
            return array2;
        }

        public string[] GetAllScenePaths()
        {
            IL2Object il2Object = Instance_Class.GetMethod("GetAllScenePaths").Invoke(this, true);
            if (il2Object == null)
            {
                return null;
            }
            IntPtr[] array = new IL2Array<IntPtr>(il2Object.Pointer).ToArray();
            int num = array.Length;
            string[] array2 = new string[num];
            for (int i = 0; i < num; i++)
            {
                array2[i] = new IL2String(array[i]).ToString();
            }
            return array2;
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.AssetBundleModule"].GetClass("AssetBundle", "UnityEngine");
    }
}
