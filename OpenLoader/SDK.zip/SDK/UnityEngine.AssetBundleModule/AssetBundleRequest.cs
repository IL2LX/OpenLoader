﻿using System;
using IL2CPP_Core.Objects;

namespace UnityEngine
{
    public class AssetBundleRequest : AsyncOperation
    {
        public AssetBundleRequest(IntPtr ptr) : base(ptr)
        {
        }

        public Object asset
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("asset").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<Object>();
            }
        }

        public Object[] allAssets
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("allAssets").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return new IL2Array<IntPtr>(il2Object.Pointer).ToArray<Object>();
            }
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.AssetBundleModule"].GetClass("AssetBundleRequest", "UnityEngine");
    }
}
