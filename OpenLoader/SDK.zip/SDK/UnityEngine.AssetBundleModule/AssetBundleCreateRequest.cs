﻿using System;
using IL2CPP_Core.Objects;

namespace UnityEngine
{
    public class AssetBundleCreateRequest : AsyncOperation
    {
        public AssetBundleCreateRequest(IntPtr ptr) : base(ptr)
        {
        }

        public AssetBundle assetBundle
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("assetBundle").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<AssetBundle>();
            }
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.AssetBundleModule"].GetClass("AssetBundleCreateRequest", "UnityEngine");
    }
}
