﻿using System;
using IL2CPP_Core.Objects;

namespace UnityEngine
{
    public class AssetBundleRecompressOperation : AsyncOperation
    {
        public AssetBundleRecompressOperation(IntPtr ptr) : base(ptr)
        {
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.AssetBundleModule"].GetClass("AssetBundleRecompressOperation", "UnityEngine");
    }
}
