﻿using System;
using System.Linq;
using System.Reflection;
using IL2CPP_Core.Objects;

public static class IL2Cast
{
	public static IL2Class ToCPP(this Type type)
	{
		if (type == null)
		{
			throw new ArgumentNullException();
		}
		IL2Class il2Class = null;
		string text = type.Assembly.FullName;
		text = text.Split(new char[]
		{
			','
		})[0];
		IL2Assembly il2Assembly;
		if (IL2CPP.AssemblyList.TryGetValue(text, out il2Assembly))
		{
			il2Class = il2Assembly.GetClass(type.Name, type.Namespace);
		}
		if (il2Class == null)
		{
			il2Class = (IL2Class)type.GetFields().First((FieldInfo x) => x.IsStatic && x.FieldType == typeof(IL2Class)).GetValue(null);
		}
		return il2Class;
	}

	public static IL2Object ToIL2Object(this Type type)
	{
		if (type == null)
		{
			return null;
		}
		return type.ToCPP().GetIL2Type.GetObject();
	}
}
