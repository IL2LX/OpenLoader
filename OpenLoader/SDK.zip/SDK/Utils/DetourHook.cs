﻿using System;
using System.Runtime.InteropServices;

namespace SDK.Utils
{
    public static class DetourHook
    {
        public static _VRC_CreateHook VRC_CreateHook { get; private set; }

        private static T CreateDelegate<T>(IntPtr method) where T : Delegate
        {
            return Marshal.GetDelegateForFunctionPointer(method, typeof(T)) as T;
        }

        public static void CreateInstance(IntPtr mVRC_CreateHook)
        {
            VRC_CreateHook = CreateDelegate<_VRC_CreateHook>(mVRC_CreateHook);
        }

        public unsafe delegate void _VRC_CreateHook(void** pTarget, void* pDetour);
    }
}
