﻿using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;

namespace SDK.Utils
{
    public class CoroutineManager
    {
        public CoroutineManager(IEnumerator routine)
        {
            this._routine = routine;
            this._isRunning = false;
        }

        internal static void Updater()
        {
            for (int i = 0; i < MCoroutines.Count; i++)
            {
                MCoroutines[i].Update();
            }
        }

        public void Update()
        {
            if (this._isRunning && this._routine != null)
            {
                if (this._routine.Current == null)
                {
                    this._routine.MoveNext();
                    return;
                }
                if (this._routine.Current is WaitForSeconds)
                {
                    if (((WaitForSeconds)this._routine.Current).IsFinished())
                    {
                        if (!this._routine.MoveNext())
                        {
                            this.Stop();
                        }
                        return;
                    }
                    return;
                }
                else if (!this._routine.MoveNext())
                {
                    this.Stop();
                }
            }
        }

        public void Start()
        {
            this._isRunning = true;
            MCoroutines.Add(this);
        }

        public void Stop()
        {
            this._isRunning = false;
            MCoroutines.Remove(this);
        }

        private static Thread updaterThread;
        private static bool updaterRunning = false;

        public static void Start(int intervalMs = 50)
        {
            if (updaterRunning) return;

            updaterRunning = true;
            updaterThread = new Thread(() =>
            {
                while (updaterRunning)
                {
                    Updater();
                    Thread.Sleep(intervalMs);
                }
            });
            updaterThread.IsBackground = true;
            updaterThread.Start();
        }

        public static void StopAutoUpdater()
        {
            updaterRunning = false;
            updaterThread = null;
        }

        public static List<CoroutineManager> MCoroutines = new List<CoroutineManager>();
        private IEnumerator _routine;
        private bool _isRunning;
    }
}
