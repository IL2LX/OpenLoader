﻿using IL2CPP_Core.Objects;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace SDK.Utils
{
    public static class PatchUtils
    {
        public static T FastPatch<T>(IL2Method method, T newMethod) where T : Delegate
        {
            return new IL2Patch(method, (Delegate)newMethod).CreateDelegate<T>();
        }

        public static T FastPatch<T>(IntPtr method, T newMethod) where T : Delegate
        {
            return new IL2Patch(method, (Delegate)newMethod).CreateDelegate<T>();
        }

        public static void Prefix(IL2Method methodOrg, Delegate YourFunc)
        {
            Delegate b = !((IL2Object)methodOrg == (IL2Object)null) ? new IL2Patch(methodOrg, YourFunc).CreateDelegate<Delegate>() : throw new NullReferenceException();
            Delegate.Combine(YourFunc, b);
        }

        public static Delegate Postfix(IL2Method methodOrg, MethodInfo YourFunc)
        {
            List<Type> typeList = new List<Type>();
            foreach (ParameterInfo parameter in YourFunc.GetParameters())
                typeList.Add(parameter.ParameterType);
            Delegate newMethod = DelegateFactory.CreateDelegate(YourFunc.Name, typeList.ToArray());
            return !((IL2Object)methodOrg == (IL2Object)null) ? new IL2Patch(methodOrg, newMethod).CreateDelegate<Delegate>() : throw new NullReferenceException();
        }

        public class DelegateFactory
        {
            private static List<Delegate> delegates = new List<Delegate>();

            public static Delegate CreateDelegate(string delegateName, params Type[] delegateParameterTypes)
            {
                Delegate @delegate = Delegate.CreateDelegate(typeof(Delegate).GetNestedType("Delegate", BindingFlags.Static | BindingFlags.Public).MakeGenericType(delegateParameterTypes), (Type)null, delegateName);
                delegates.Add(@delegate);
                return @delegate;
            }
        }
    }
}

