﻿using System.Diagnostics;

namespace SDK.Utils
{
    public class WaitForSeconds
    {
        private readonly float _duration;
        private readonly Stopwatch _stopwatch;

        public WaitForSeconds(float duration)
        {
            _duration = duration;
            _stopwatch = Stopwatch.StartNew();
        }

        public bool IsFinished()
        {
            return _stopwatch.Elapsed.TotalSeconds >= _duration;
        }
    }
}
