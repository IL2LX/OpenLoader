﻿using System;
using System.Linq;
using IL2CPP_Core.Objects;
using MoPhoGames.USpeak.Core;
using UnityEngine;
using VRC;

public class USpeaker : MonoBehaviour
{
    public USpeaker(IntPtr ptr) : base(ptr)
    {
    }

    public unsafe static float LocalGain
    {
        get
        {
            IL2Field il2Field = Instance_Class.GetField("LocalGain");
            if (il2Field == null)
            {
                (il2Field = Instance_Class.GetFields().Skip(3).FirstOrDefault<IL2Field>()).Name = "LocalGain";
                if (il2Field == null)
                {
                    return 0f;
                }
            }
            return il2Field.GetValue<float>().GetValue();
        }
        set
        {
            IL2Field il2Field = Instance_Class.GetField("LocalGain");
            if (il2Field == null)
            {
                (il2Field = Instance_Class.GetFields().Skip(3).FirstOrDefault<IL2Field>()).Name = "LocalGain";
                if (il2Field == null)
                {
                    return;
                }
            }
            if (il2Field != null)
            {
                il2Field.SetValue(new IntPtr((void*)(&value)));
            }
        }
    }

    static USpeaker()
    {
        IL2Assembly il2Assembly = IL2CPP.AssemblyList["Assembly-CSharp"];
        IL2Field field = Player.Instance_Class.GetField("_USpeaker");
        Instance_Class = il2Assembly.GetClass((field != null) ? field.ReturnType.Name : null);
    }

    public new static IL2Class Instance_Class;

    public struct EncodeInfo
    {
        public USpeakFrameContainer frameContainer;

        public float[] pcmData;

        public float pcmDataLength;

        public ushort frameIndex;

        public static IL2Class Instance_Class = USpeaker.Instance_Class.GetNestedTypes().FirstOrDefault(delegate (IL2Class x)
        {
            if (x.GetFields().Length == 4)
            {
                if (x.GetField((IL2Field y) => y.ReturnType.Name == typeof(float).FullName) != null)
                {
                    if (x.GetField((IL2Field y) => y.ReturnType.Name == typeof(float[]).FullName) != null)
                    {
                        return x.GetField((IL2Field y) => y.ReturnType.Name == typeof(ushort).FullName) != null;
                    }
                }
            }
            return false;
        });
    }
}
