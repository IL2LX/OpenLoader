using System;
using IL2CPP_Core.Objects;
using UnityEngine;
using VRC;
using VRC.Core;

public class VRCPlayer : VRCNetworkBehaviour
{
    public VRCPlayer(IntPtr ptr) : base(ptr) { }

    static VRCPlayer()
    {
        Instance_Class = IL2CPP.AssemblyList["Assembly-CSharp"].GetClass(VRC.Player.Instance_Class.GetField("_vrcplayer").ReturnType.Name);

        try
        {
            // void LoadAvatar(ApiAvatar a)
            Instance_Class.GetMethod(x => x.GetParameters().Length == 1 && x.GetParameters()[0].ReturnType.Name == ApiAvatar.Instance_Class.FullName).Name = nameof(LoadAvatar);
        }
        catch { "LoadAvatar(ApiAvatar a) not found!".RedPrefix("VRCPlayer"); }

        try
        {
            // void LoadAvatar(bool forceLoad = false)
            Instance_Class.GetMethod(x => x.Name == Instance_Class.GetMethod(nameof(LoadAvatar)).OriginalName).Name = nameof(LoadAvatar);
        }
        catch { "LoadAvatar(bool forceLoad = false) not found!".RedPrefix("VRCPlayer"); }
    }

    // <!---------- ---------- ---------->
    // <!---------- PROPERTY'S ---------->
    // <!---------- ---------- ---------->
    public Player player
    {
        get
        {
            IL2Property property = Instance_Class.GetProperty(nameof(player));
            if (property == null)
                (property = Instance_Class.GetProperty(Player.Instance_Class)).Name = nameof(player);
            return property?.GetGetMethod().Invoke(this)?.GetValue<Player>();
        }
    }

    public ApiAvatar AvatarModel
    {
        get
        {
            IL2Property property = Instance_Class.GetProperty(nameof(AvatarModel));
            if (property == null)
                (property = Instance_Class.GetProperty(ApiAvatar.Instance_Class)).Name = nameof(AvatarModel);
            return property?.GetGetMethod().Invoke(this)?.GetValue<ApiAvatar>();
        }
    }

    public PlayerNet playerNet
    {
        get
        {
            IL2Property property = Instance_Class.GetProperty(nameof(playerNet));
            if (property == null)
                (property = Instance_Class.GetProperty(PlayerNet.Instance_Class)).Name = nameof(playerNet);
            return property.GetGetMethod().Invoke(this)?.GetValue<PlayerNet>();
        }
    }
    
    public VRCAvatarManager AvatarManager
    {
        get
        {
            IL2Property property = Instance_Class.GetProperty(nameof(AvatarManager));
            if (property == null)
                (property = Instance_Class.GetProperty(VRCAvatarManager.Instance_Class)).Name = nameof(AvatarManager);
            return property.GetGetMethod().Invoke(this)?.GetValue<VRCAvatarManager>();
        }
    }

    public USpeaker uSpeaker
    {
        get
        {
            IL2Property property = Instance_Class.GetProperty(nameof(uSpeaker));
            if (property == null)
                (property = Instance_Class.GetProperty(USpeaker.Instance_Class)).Name = nameof(uSpeaker);
            return property?.GetGetMethod().Invoke(this)?.GetValue<USpeaker>();
        }
    }

    public static VRCPlayer Instance
    {
        get
        {
            IL2Field field = Instance_Class.GetField(nameof(Instance));
            if (field == null)
                (field = Instance_Class.GetField(x => x.Instance)).Name = nameof(Instance);
            return field.GetValue()?.GetValue<VRCPlayer>();
        }
    }

    public void LoadAvatar(ApiAvatar a)
    {
        Instance_Class.GetMethod(nameof(LoadAvatar), x => x.GetParameters()[0].ReturnType.Name != typeof(bool).FullName).Invoke(this, new IntPtr[] { a == null ? IntPtr.Zero : a.Pointer });
    }

    unsafe public void LoadAvatar(bool forceLoad = false)
    {
        Instance_Class.GetMethod(nameof(LoadAvatar), x => x.GetParameters()[0].ReturnType.Name == typeof(bool).FullName).Invoke(this, new IntPtr[] { new IntPtr(&forceLoad) });
    }


    public void RefreshState()
    {
        Instance_Class.GetMethod(nameof(RefreshState))?.Invoke(this);
    }

    public void ReloadAvatarNetworkedRPC(VRC.Player player)
    {
        Instance_Class.GetMethod(nameof(ReloadAvatarNetworkedRPC))?.Invoke(this, new IntPtr[] { player.Pointer });
    }

    public PlayerSelector playerSelector
    {
        get
        {
            IL2Field field = Instance_Class.GetField(nameof(playerSelector));
            if (field == null)
                (field = Instance_Class.GetField(PlayerSelector.Instance_Class)).Name = nameof(playerSelector);

            return field?.GetValue(this)?.GetValue<PlayerSelector>();
        }
    }

    public GameObject avatarGameObject
    {
        get
        {
            IL2Field field = Instance_Class.GetField(nameof(avatarGameObject));
            if (field == null)
                (field = Instance_Class.GetField(GameObject.Instance_Class)).Name = nameof(avatarGameObject);

            return field?.GetValue(this)?.GetValue<GameObject>();
        }
    }
    public Animator avatarAnimator
    {
        get
        {
            IL2Field field = Instance_Class.GetField(nameof(avatarAnimator));
            if (field == null)
                (field = Instance_Class.GetField(Animator.Instance_Class)).Name = nameof(avatarAnimator);

            return field.GetValue(this)?.GetValue<Animator>();
        }
    }

    public PlayerNameplate nameplate
    {
        get
        {
            IL2Field field = Instance_Class.GetField(nameof(nameplate));
            if (field == null)
                (field = Instance_Class.GetField(PlayerNameplate.Instance_Class)).Name = nameof(nameplate);

            return field.GetValue(this)?.GetValue<PlayerNameplate>();
        }
    }
    public enum NetworkChange
    {
        Visible = 1,
        ModTag = 2,
        VRMode = 4,
        Status = 8,
        StatusDesc = 16,
        SteamId = 32,
        ShowRank = 64,
        Avatar = 128,
        User = 256
    }

    public static new IL2Class Instance_Class;
}