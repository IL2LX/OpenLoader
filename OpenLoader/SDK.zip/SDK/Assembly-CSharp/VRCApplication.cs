﻿using System;
using UnityEngine;
using IL2CPP_Core.Objects;
using System.Linq;

public class VRCApplication : MonoBehaviour
{
    public VRCApplication(IntPtr ptr) : base(ptr) { }

    public static VRCApplication Instance
    {
        get
        {
            IL2Property property = Instance_Class.GetProperty(nameof(Instance));
            if (property == null)
                (property = Instance_Class.GetProperty(x => x.Instance)).Name = nameof(Instance);
            return property?.GetGetMethod().Invoke()?.GetValue<VRCApplication>();
        }
    }

    public new static IL2Class Instance_Class = IL2CPP.AssemblyList["Assembly-CSharp"].GetClasses().Where(delegate (IL2Class x)
    {
        if (x.GetMethod("OnApplicationQuit", (IL2Method y) => y.IsPrivate) != null)
        {
            return x.GetMethod("OnApplicationPause", (IL2Method y) => y.IsPrivate) != null;
        }
        return false;
    }).FirstOrDefault((IL2Class x) => x.GetProperties((IL2Property y) => y.Instance).Length == 1);
}
