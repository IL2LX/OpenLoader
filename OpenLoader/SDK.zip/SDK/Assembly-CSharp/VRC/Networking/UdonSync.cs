﻿using System;
using System.Linq;
using IL2CPP_Core.Objects;

namespace VRC.Networking
{
    public class UdonSync : VRCNetworkBehaviour
    {
        public UdonSync(IntPtr ptr) : base(ptr)
        {
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["Assembly-CSharp"].GetClasses().FirstOrDefault((IL2Class x) => x.GetMethod("UdonSyncRunProgramAsRPC") != null);
    }
}
