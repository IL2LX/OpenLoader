﻿using System;
using System.Collections.Generic;
using IL2CPP_Core.Objects;
using UnityEngine;
using VRC.Udon.Common.Interfaces;

namespace VRC.Udon
{
    public class UdonBehaviour : MonoBehaviour
    {
        public UdonBehaviour(IntPtr ptr) : base(ptr)
        {
        }

        public unsafe SyncType SyncMethod
        {
            get
            {
                return Instance_Class.GetProperty("SyncMethod").GetGetMethod().Invoke<SyncType>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("SyncMethod").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public bool SyncIsContinuous
        {
            get
            {
                return Instance_Class.GetProperty("SyncIsContinuous").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public bool SyncIsManual
        {
            get
            {
                return Instance_Class.GetProperty("SyncIsManual").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public unsafe bool DisableInteractive
        {
            get
            {
                return Instance_Class.GetProperty("DisableInteractive").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("DisableInteractive").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public unsafe bool IsNetworkingSupported
        {
            get
            {
                return Instance_Class.GetProperty("IsNetworkingSupported").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("IsNetworkingSupported").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public bool IsInteractive
        {
            get
            {
                return Instance_Class.GetProperty("IsInteractive").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public unsafe bool DisableEventProcessing
        {
            get
            {
                return Instance_Class.GetProperty("DisableEventProcessing").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("DisableEventProcessing").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public int ProgramId
        {
            get
            {
                return Instance_Class.GetProperty("ProgramId").GetGetMethod().Invoke<int>(this, true).GetValue();
            }
        }

        public ulong ProgramSize
        {
            get
            {
                return Instance_Class.GetProperty("ProgramSize").GetGetMethod().Invoke<ulong>(this, true).GetValue();
            }
        }

        public unsafe void OnAnimatorIK(int layerIndex)
        {
            Instance_Class.GetMethod("OnAnimatorIK").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&layerIndex))
            }, true);
        }

        public void OnBecameInvisible()
        {
            Instance_Class.GetMethod("OnBecameInvisible").Invoke(this, true);
        }

        public void OnBecameVisible()
        {
            Instance_Class.GetMethod("OnBecameVisible").Invoke(this, true);
        }

        public void OnDestroy()
        {
            Instance_Class.GetMethod("OnDestroy").Invoke(this, true);
        }

        public void OnDisable()
        {
            Instance_Class.GetMethod("OnDisable").Invoke(this, true);
        }

        public void OnDrawGizmos()
        {
            Instance_Class.GetMethod("OnDrawGizmos").Invoke(this, true);
        }

        public void OnDrawGizmosSelected()
        {
            Instance_Class.GetMethod("OnDrawGizmosSelected").Invoke(this, true);
        }

        public void OnEnable()
        {
            Instance_Class.GetMethod("OnEnable").Invoke(this, true);
        }

        public unsafe void OnJointBreak(float breakForce)
        {
            Instance_Class.GetMethod("OnJointBreak").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&breakForce))
            }, true);
        }

        public void OnMouseDown()
        {
            Instance_Class.GetMethod("OnMouseDown").Invoke(this, true);
        }

        public void OnMouseDrag()
        {
            Instance_Class.GetMethod("OnMouseDrag").Invoke(this, true);
        }

        public void OnMouseEnter()
        {
            Instance_Class.GetMethod("OnMouseEnter").Invoke(this, true);
        }

        public void OnMouseExit()
        {
            Instance_Class.GetMethod("OnMouseExit").Invoke(this, true);
        }

        public void OnMouseOver()
        {
            Instance_Class.GetMethod("OnMouseOver").Invoke(this, true);
        }

        public void OnMouseUp()
        {
            Instance_Class.GetMethod("OnMouseUp").Invoke(this, true);
        }

        public void OnMouseUpAsButton()
        {
            Instance_Class.GetMethod("OnMouseUpAsButton").Invoke(this, true);
        }

        public void OnParticleCollision(GameObject other)
        {
            Instance_Class.GetMethod("OnParticleCollision").Invoke(this, new IntPtr[]
            {
                (other != null) ? other.Pointer : IntPtr.Zero
            }, true);
        }

        public void OnParticleTrigger()
        {
            Instance_Class.GetMethod("OnParticleTrigger").Invoke(this, true);
        }

        public void OnPostRender()
        {
            Instance_Class.GetMethod("OnPostRender").Invoke(this, true);
        }

        public void OnPreCull()
        {
            Instance_Class.GetMethod("OnPreCull").Invoke(this, true);
        }

        public void OnPreRender()
        {
            Instance_Class.GetMethod("OnPreRender").Invoke(this, true);
        }

        public void OnRenderImage(RenderTexture src, RenderTexture dest)
        {
            Instance_Class.GetMethod("OnRenderImage").Invoke(this, new IntPtr[]
            {
                (src != null) ? src.Pointer : IntPtr.Zero,
                (dest != null) ? dest.Pointer : IntPtr.Zero
            }, true);
        }

        public void OnTransformChildrenChanged()
        {
            Instance_Class.GetMethod("OnTransformChildrenChanged").Invoke(this, true);
        }

        public void OnTransformParentChanged()
        {
            Instance_Class.GetMethod("OnTransformParentChanged").Invoke(this, true);
        }

        public void OnTriggerEnter(Collider other)
        {
            Instance_Class.GetMethod("OnTriggerEnter").Invoke(this, new IntPtr[]
            {
                (other != null) ? other.Pointer : IntPtr.Zero
            }, true);
        }

        public void OnTriggerExit(Collider other)
        {
            Instance_Class.GetMethod("OnTriggerExit").Invoke(this, new IntPtr[]
            {
                (other != null) ? other.Pointer : IntPtr.Zero
            }, true);
        }

        public void OnValidate()
        {
            Instance_Class.GetMethod("OnValidate").Invoke(this, true);
        }

        public void Interact()
        {
            Instance_Class.GetMethod("Interact").Invoke(this, true);
        }

        public void OnDrop()
        {
            Instance_Class.GetMethod("OnDrop").Invoke(this, true);
        }

        public void OnPickup()
        {
            Instance_Class.GetMethod("OnPickup").Invoke(this, true);
        }

        public void OnPickupUseDown()
        {
            Instance_Class.GetMethod("OnPickupUseDown").Invoke(this, true);
        }

        public void OnPickupUseUp()
        {
            Instance_Class.GetMethod("OnPickupUseUp").Invoke(this, true);
        }

        public void OnPreSerialization()
        {
            Instance_Class.GetMethod("OnPreSerialization").Invoke(this, true);
        }

        public void RunProgram(string eventName)
        {
            Instance_Class.GetMethod("RunProgram").Invoke(this, new IntPtr[]
            {
                new IL2String_utf8(eventName).Pointer
            }, true);
        }

        public unsafe void SendCustomNetworkEvent(NetworkEventTarget target, string eventName)
        {
            Instance_Class.GetMethod("SendCustomNetworkEvent").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&target)),
                new IL2String_utf8(eventName).Pointer
            }, true);
        }

        public UdonBehaviour() : base(IntPtr.Zero)
        {
            this.Pointer = Import.Object.il2cpp_object_new(Instance_Class.Pointer);
            Instance_Class.GetMethod(".ctor").Invoke(this.Pointer, true);
        }

        [Obsolete("Use VRCObjectSync instead")]
        public bool SynchronizePosition
        {
            get
            {
                return Instance_Class.GetField("SynchronizePosition").GetValue<bool>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("SynchronizePosition").SetValue<bool>(this, value);
            }
        }

        public bool SynchronizeAnimation
        {
            get
            {
                return Instance_Class.GetField("SynchronizeAnimation").GetValue<bool>(this).GetValue();
            }
        }

        [Obsolete("Use VRCObjectSync instead")]
        public bool AllowCollisionOwnershipTransfer
        {
            get
            {
                return Instance_Class.GetField("AllowCollisionOwnershipTransfer").GetValue<bool>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("AllowCollisionOwnershipTransfer").SetValue<bool>(this, value);
            }
        }

        [Obsolete("Use SyncMethod instead")]
        public bool Reliable
        {
            get
            {
                return Instance_Class.GetField("Reliable").GetValue<bool>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("Reliable").SetValue<bool>(this, value);
            }
        }

        public IL2Dictionary<IL2String, IL2List<uint>> _eventTable
        {
            get
            {
                IL2Object value = Instance_Class.GetField("_eventTable").GetValue(this);
                if (value == null)
                {
                    return null;
                }
                return new IL2Dictionary<IL2String, IL2List<uint>>(value.Pointer);
            }
        }

        public const string ReturnVariableName = "__returnValue";

        public enum SyncType
        {
            Unknown,
            None,
            Continuous,
            Manual
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["VRC.Udon"].GetClass("UdonBehaviour", "VRC.Udon");
    }
}
