﻿using IL2CPP_Core.Objects;
using System;
using UnityEngine;

namespace SDK.UnityEngine
{
    public sealed class SystemInfo
    {
        public static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.CoreModule"].GetClass(nameof(SystemInfo), "UnityEngine");

        public static float batteryLevel
        {
            get
            {
                return Instance_Class.GetProperty(nameof(batteryLevel)).GetGetMethod().Invoke<float>().GetValue();
            }
        }

        public static string operatingSystem
        {
            get
            {
                return Instance_Class.GetProperty(nameof(operatingSystem)).GetGetMethod().Invoke()?.GetValue<IL2String>().ToString();
            }
        }

        public static string processorType
        {
            get
            {
                return Instance_Class.GetProperty(nameof(processorType)).GetGetMethod().Invoke()?.GetValue<IL2String>().ToString();
            }
        }

        public static int processorFrequency
        {
            get
            {
                return Instance_Class.GetProperty(nameof(processorFrequency)).GetGetMethod().Invoke<int>().GetValue();
            }
        }

        public static int processorCount
        {
            get
            {
                return Instance_Class.GetProperty(nameof(processorCount)).GetGetMethod().Invoke<int>().GetValue();
            }
        }

        public static int systemMemorySize
        {
            get
            {
                return Instance_Class.GetProperty(nameof(systemMemorySize)).GetGetMethod().Invoke<int>().GetValue();
            }
        }

        public static string deviceUniqueIdentifier
        {
            get
            {
                return Instance_Class.GetProperty(nameof(deviceUniqueIdentifier)).GetGetMethod().Invoke()?.GetValue<IL2String>().ToString();
            }
        }

        public static string deviceName
        {
            get
            {
                return Instance_Class.GetProperty(nameof(deviceName)).GetGetMethod().Invoke()?.GetValue<IL2String>().ToString();
            }
        }

        public static string deviceModel
        {
            get
            {
                return Instance_Class.GetProperty(nameof(deviceModel)).GetGetMethod().Invoke()?.GetValue<IL2String>().ToString();
            }
        }

        public static bool supportsVibration
        {
            get
            {
                return Instance_Class.GetProperty(nameof(supportsVibration)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static bool supportsAudio
        {
            get
            {
                return Instance_Class.GetProperty(nameof(supportsAudio)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static int graphicsMemorySize
        {
            get
            {
                return Instance_Class.GetProperty(nameof(graphicsMemorySize)).GetGetMethod().Invoke<int>().GetValue();
            }
        }

        public static string graphicsDeviceName
        {
            get
            {
                return Instance_Class.GetProperty(nameof(graphicsDeviceName)).GetGetMethod().Invoke()?.GetValue<IL2String>().ToString();
            }
        }

        public static string graphicsDeviceVendor
        {
            get
            {
                return Instance_Class.GetProperty("graphicsDeviceName").GetGetMethod().Invoke()?.GetValue<IL2String>().ToString();
            }
        }

        public static int graphicsDeviceID
        {
            get
            {
                return Instance_Class.GetProperty(nameof(graphicsDeviceID)).GetGetMethod().Invoke<int>().GetValue();
            }
        }

        public static int graphicsDeviceVendorID
        {
            get
            {
                return Instance_Class.GetProperty(nameof(graphicsDeviceVendorID)).GetGetMethod().Invoke<int>().GetValue();
            }
        }

        public static bool graphicsUVStartsAtTop
        {
            get
            {
                return Instance_Class.GetProperty(nameof(graphicsUVStartsAtTop)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static string graphicsDeviceVersion
        {
            get
            {
                return Instance_Class.GetProperty(nameof(graphicsDeviceVersion)).GetGetMethod().Invoke()?.GetValue<IL2String>().ToString();
            }
        }

        public static int graphicsShaderLevel
        {
            get
            {
                return Instance_Class.GetProperty(nameof(graphicsShaderLevel)).GetGetMethod().Invoke<int>().GetValue();
            }
        }

        public static bool graphicsMultiThreaded
        {
            get
            {
                return Instance_Class.GetProperty(nameof(graphicsMultiThreaded)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static bool supportsMotionVectors
        {
            get
            {
                return Instance_Class.GetProperty(nameof(supportsMotionVectors)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        [Obsolete]
        public static bool supportsImageEffects
        {
            get
            {
                return Instance_Class.GetProperty(nameof(supportsImageEffects)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static bool supports3DRenderTextures
        {
            get
            {
                return Instance_Class.GetProperty(nameof(supports3DRenderTextures)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static bool supportsComputeShaders
        {
            get
            {
                return Instance_Class.GetProperty(nameof(supportsComputeShaders)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static bool supportsGeometryShaders
        {
            get
            {
                return Instance_Class.GetProperty(nameof(supportsGeometryShaders)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static bool supportsInstancing
        {
            get
            {
                return Instance_Class.GetProperty(nameof(supportsInstancing)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static int supportedRenderTargetCount
        {
            get
            {
                return Instance_Class.GetProperty(nameof(supportedRenderTargetCount)).GetGetMethod().Invoke<int>().GetValue();
            }
        }

        public static bool usesReversedZBuffer
        {
            get
            {
                return Instance_Class.GetProperty(nameof(usesReversedZBuffer)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static unsafe bool SupportsRenderTextureFormat(RenderTextureFormat format)
        {
            return Instance_Class.GetMethod(nameof(SupportsRenderTextureFormat)).Invoke<bool>(new IntPtr[1]
            {
                new IntPtr((void*) &format)
            }).GetValue();
        }

        public static unsafe bool SupportsTextureFormat(TextureFormat format)
        {
            return Instance_Class.GetMethod(nameof(SupportsTextureFormat)).Invoke<bool>(new IntPtr[1]
            {
                new IntPtr((void*) &format)
            }).GetValue();
        }

        public static int maxTextureSize
        {
            get
            {
                return Instance_Class.GetProperty(nameof(maxTextureSize)).GetGetMethod().Invoke<int>().GetValue();
            }
        }

        public static int maxCubemapSize
        {
            get
            {
                return Instance_Class.GetProperty(nameof(maxCubemapSize)).GetGetMethod().Invoke<int>().GetValue();
            }
        }

        public static bool supportsAsyncGPUReadback
        {
            get
            {
                return Instance_Class.GetProperty(nameof(supportsAsyncGPUReadback)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static bool supportsRayTracing
        {
            get
            {
                return Instance_Class.GetProperty(nameof(supportsRayTracing)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static bool usesLoadStoreActions
        {
            get
            {
                return Instance_Class.GetProperty(nameof(usesLoadStoreActions)).GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static string GetDeviceUniqueIdentifier()
        {
            return Instance_Class.GetMethod(nameof(GetDeviceUniqueIdentifier)).Invoke().GetValue<IL2String>().ToString();
        }
    }
}

