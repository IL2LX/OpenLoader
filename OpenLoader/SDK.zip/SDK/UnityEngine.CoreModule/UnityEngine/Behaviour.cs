﻿using System;
using IL2CPP_Core.Objects;

namespace UnityEngine
{
    public class Behaviour : Component
    {
        public Behaviour(IntPtr ptr) : base(ptr)
        {
        }

        public unsafe bool enabled
        {
            get
            {
                return Instance_Class.GetProperty("enabled").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("enabled").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public bool isActiveAndEnabled
        {
            get
            {
                return Instance_Class.GetProperty("isActiveAndEnabled").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.CoreModule"].GetClass("Behaviour", "UnityEngine");
    }
}
