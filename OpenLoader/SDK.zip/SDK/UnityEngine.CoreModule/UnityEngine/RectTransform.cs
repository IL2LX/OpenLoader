﻿using System;
using IL2CPP_Core.Objects;

namespace UnityEngine
{
    public class RectTransform : Transform
    {
        public RectTransform(IntPtr ptr) : base(ptr)
        {
        }

        public RectTransform() : base(IntPtr.Zero)
        {
            this.Pointer = Import.Object.il2cpp_object_new(Instance_Class.Pointer);
            Instance_Class.GetMethod(".ctor").Invoke(this.Pointer, true);
        }

        public unsafe Vector2 anchoredPosition
        {
            get
            {
                return Instance_Class.GetProperty("anchoredPosition").GetGetMethod().Invoke<Vector2>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("anchoredPosition").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public unsafe Vector2 anchorMax
        {
            get
            {
                return Instance_Class.GetProperty("anchorMax").GetGetMethod().Invoke<Vector2>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("anchorMax").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public unsafe Vector2 pivot
        {
            get
            {
                return Instance_Class.GetProperty("pivot").GetGetMethod().Invoke<Vector2>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("pivot").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public unsafe Vector2 anchorMin
        {
            get
            {
                return Instance_Class.GetProperty("anchorMin").GetGetMethod().Invoke<Vector2>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("anchorMin").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public unsafe Vector2 sizeDelta
        {
            get
            {
                return Instance_Class.GetProperty("sizeDelta").GetGetMethod().Invoke<Vector2>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("sizeDelta").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.CoreModule"].GetClass("RectTransform", "UnityEngine");
    }
}
