﻿using System;
using IL2CPP_Core.Objects;

namespace UnityEngine.SceneManagement
{
    [Serializable]
    public struct Scene
    {
        private unsafe static bool IsValidInternal(int sceneHandle)
        {
            return Instance_Class.GetMethod("IsValidInternal").Invoke<bool>(new IntPtr[]
            {
                new IntPtr((void*)(&sceneHandle))
            }).GetValue();
        }

        private unsafe static string GetNameInternal(int sceneHandle)
        {
            IL2Object il2Object = Instance_Class.GetMethod("GetNameInternal").Invoke(new IntPtr[]
            {
                new IntPtr((void*)(&sceneHandle))
            });
            if (il2Object == null)
            {
                return null;
            }
            return il2Object.GetValue<IL2String>().ToString();
        }

        private unsafe static bool GetIsLoadedInternal(int sceneHandle)
        {
            return Instance_Class.GetMethod("GetIsLoadedInternal").Invoke<bool>(new IntPtr[]
            {
                new IntPtr((void*)(&sceneHandle))
            }).GetValue();
        }

        private unsafe static int GetBuildIndexInternal(int sceneHandle)
        {
            return Instance_Class.GetMethod("GetBuildIndexInternal").Invoke<int>(new IntPtr[]
            {
                new IntPtr((void*)(&sceneHandle))
            }).GetValue();
        }

        private unsafe static int GetRootCountInternal(int sceneHandle)
        {
            return Instance_Class.GetMethod("GetRootCountInternal").Invoke<int>(new IntPtr[]
            {
                new IntPtr((void*)(&sceneHandle))
            }).GetValue();
        }

        public int handle
        {
            get
            {
                return this.m_Handle;
            }
        }

        public bool IsValid()
        {
            return IsValidInternal(this.handle);
        }

        public string name
        {
            get
            {
                return GetNameInternal(this.handle);
            }
        }

        public bool isLoaded
        {
            get
            {
                return GetIsLoadedInternal(this.handle);
            }
        }

        public int buildIndex
        {
            get
            {
                return GetBuildIndexInternal(this.handle);
            }
        }

        public int rootCount
        {
            get
            {
                return GetRootCountInternal(this.handle);
            }
        }

        public unsafe GameObject[] GetRootGameObjects()
        {
            Scene scene = this;
            IL2Object il2Object = Instance_Class.GetMethod("GetRootGameObjects").Invoke(new IntPtr((void*)(&scene)), true);
            if (il2Object == null)
            {
                return null;
            }
            return new IL2Array<IntPtr>(il2Object.Pointer).ToArray<GameObject>();
        }

        public static bool operator ==(Scene lhs, Scene rhs)
        {
            return lhs.handle == rhs.handle;
        }

        public static bool operator !=(Scene lhs, Scene rhs)
        {
            return lhs.handle != rhs.handle;
        }

        public override int GetHashCode()
        {
            return this.m_Handle;
        }

        public override bool Equals(object other)
        {
            bool result;
            if (!(other is Scene))
            {
                result = false;
            }
            else
            {
                Scene scene = (Scene)other;
                result = (this.handle == scene.handle);
            }
            return result;
        }

        private int m_Handle;
        public static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.CoreModule"].GetClass("Scene", "UnityEngine.SceneManagement");
    }
}
