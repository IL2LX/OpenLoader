﻿using System;
using IL2CPP_Core.Objects;

namespace UnityEngine.SceneManagement
{
    public class SceneManager : IL2Object
    {
        public SceneManager(IntPtr ptr) : base(ptr)
        {
        }

        public static int sceneCount
        {
            get
            {
                return Instance_Class.GetProperty("sceneCount").GetGetMethod().Invoke<int>().GetValue();
            }
        }

        public static int sceneCountInBuildSettings
        {
            get
            {
                return Instance_Class.GetProperty("sceneCountInBuildSettings").GetGetMethod().Invoke<int>().GetValue();
            }
        }

        public static AsyncOperation UnloadSceneAsync(string sceneName, UnloadSceneOptions options)
        {
            return Instance_Class.GetMethod("GetActiveScene").Invoke().GetValue<AsyncOperation>();
        }

        public static Scene GetActiveScene()
        {
            return Instance_Class.GetMethod("GetActiveScene").Invoke<Scene>().GetValue();
        }

        public unsafe static Scene GetSceneAt(int index)
        {
            return Instance_Class.GetMethod("GetSceneAt").Invoke<Scene>(new IntPtr[]
            {
                new IntPtr((void*)(&index))
            }).GetValue();
        }

        public static Scene GetSceneByName(string name)
        {
            return Instance_Class.GetMethod("GetSceneByName").Invoke<Scene>(new IntPtr[]
            {
                new IL2String_utf8(name).Pointer
            }).GetValue();
        }

        public unsafe static bool SetActiveScene(Scene scene)
        {
            return Instance_Class.GetMethod("SetActiveScene").Invoke<bool>(new IntPtr[]
            {
                new IntPtr((void*)(&scene))
            }).GetValue();
        }

        public static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.CoreModule"].GetClass("SceneManager", "UnityEngine.SceneManagement");
    }
}
