using System;
using IL2CPP_Core.Objects;

namespace UnityEngine
{
    public sealed class Camera : MonoBehaviour
    {
        public Camera(IntPtr ptr) : base(ptr)
        {
        }

        public static Camera main
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("main").GetGetMethod().Invoke();
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<Camera>();
            }
        }

        public static Camera current
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("current").GetGetMethod().Invoke();
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<Camera>();
            }
        }

        public unsafe float nearClipPlane
        {
            get
            {
                return Instance_Class.GetProperty("nearClipPlane").GetGetMethod().Invoke<float>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("nearClipPlane").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public unsafe float fieldOfView
        {
            get
            {
                return Instance_Class.GetProperty("fieldOfView").GetGetMethod().Invoke<float>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("fieldOfView").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public unsafe Ray ScreenPointToRay(Vector3 pos)
        {
            return Instance_Class.GetMethod("ScreenPointToRay", (IL2Method x) => x.GetParameters().Length == 1).Invoke<Ray>(this, new IntPtr[]
            {
                new IntPtr((void*)(&pos))
            }, true).GetValue();
        }

        public unsafe Vector3 WorldToScreenPoint(Vector3 pos)
        {
            return Instance_Class.GetMethod("WorldToScreenPoint", (IL2Method x) => x.GetParameters().Length == 1).Invoke<Vector3>(this, new IntPtr[]
            {
                new IntPtr((void*)(&pos))
            }, true).GetValue();
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.CoreModule"].GetClass("Camera", "UnityEngine");
    }
}
