﻿using System;
using System.ComponentModel;
using IL2CPP_Core.Objects;

namespace UnityEngine
{
    // Token: 0x0200010A RID: 266
    public struct Quaternion
    {
        // Token: 0x0600063E RID: 1598 RVA: 0x0001783C File Offset: 0x00015A3C
        public Quaternion(float x, float y, float z, float w)
        {
            this.x = x;
            this.y = y;
            this.z = z;
            this.w = w;
        }

        // Token: 0x0600063F RID: 1599 RVA: 0x0001785B File Offset: 0x00015A5B
        public unsafe static Quaternion AngleAxis(float angle, Vector3 axis)
        {
            return Quaternion.Instance_Class.GetMethod("AngleAxis").Invoke<Quaternion>(new IntPtr[]
            {
                new IntPtr((void*)(&angle)),
                new IntPtr((void*)(&axis))
            }).GetValue();
        }

        // Token: 0x06000640 RID: 1600 RVA: 0x00017892 File Offset: 0x00015A92
        public unsafe static Quaternion FromToRotation(Vector3 fromDirection, Vector3 toDirection)
        {
            return Quaternion.Instance_Class.GetMethod("FromToRotation").Invoke<Quaternion>(new IntPtr[]
            {
                new IntPtr((void*)(&fromDirection)),
                new IntPtr((void*)(&toDirection))
            }).GetValue();
        }

        // Token: 0x06000641 RID: 1601 RVA: 0x000178C9 File Offset: 0x00015AC9
        public void SetFromToRotation(Vector3 fromDirection, Vector3 toDirection)
        {
            this = Quaternion.FromToRotation(fromDirection, toDirection);
        }

        // Token: 0x06000642 RID: 1602 RVA: 0x000178D8 File Offset: 0x00015AD8
        public unsafe static Quaternion LookRotation(Vector3 forward, [DefaultValue("Vector3.up")] Vector3 upwards)
        {
            return Quaternion.Instance_Class.GetMethod("LookRotation", (IL2Method x) => x.GetParameters().Length == 2).Invoke<Quaternion>(new IntPtr[]
            {
                new IntPtr((void*)(&forward)),
                new IntPtr((void*)(&upwards))
            }).GetValue();
        }

        // Token: 0x06000643 RID: 1603 RVA: 0x0001793C File Offset: 0x00015B3C
        public unsafe static Quaternion LookRotation(Vector3 forward)
        {
            return Quaternion.Instance_Class.GetMethod("LookRotation", (IL2Method x) => x.GetParameters().Length == 1).Invoke<Quaternion>(new IntPtr[]
            {
                new IntPtr((void*)(&forward))
            }).GetValue();
        }

        // Token: 0x06000644 RID: 1604 RVA: 0x00017994 File Offset: 0x00015B94
        public unsafe static Quaternion Slerp(Quaternion a, Quaternion b, float t)
        {
            return Quaternion.Instance_Class.GetMethod("Slerp").Invoke<Quaternion>(new IntPtr[]
            {
                new IntPtr((void*)(&a)),
                new IntPtr((void*)(&b)),
                new IntPtr((void*)(&t))
            }).GetValue();
        }

        // Token: 0x06000645 RID: 1605 RVA: 0x000179E4 File Offset: 0x00015BE4
        public unsafe static Quaternion SlerpUnclamped(Quaternion a, Quaternion b, float t)
        {
            return Quaternion.Instance_Class.GetMethod("SlerpUnclamped").Invoke<Quaternion>(new IntPtr[]
            {
                new IntPtr((void*)(&a)),
                new IntPtr((void*)(&b)),
                new IntPtr((void*)(&t))
            }).GetValue();
        }

        // Token: 0x06000646 RID: 1606 RVA: 0x00017A34 File Offset: 0x00015C34
        public unsafe static Quaternion Lerp(Quaternion a, Quaternion b, float t)
        {
            return Quaternion.Instance_Class.GetMethod("Lerp").Invoke<Quaternion>(new IntPtr[]
            {
                new IntPtr((void*)(&a)),
                new IntPtr((void*)(&b)),
                new IntPtr((void*)(&t))
            }).GetValue();
        }

        // Token: 0x06000647 RID: 1607 RVA: 0x00017A84 File Offset: 0x00015C84
        public unsafe static Quaternion LerpUnclamped(Quaternion a, Quaternion b, float t)
        {
            return Quaternion.Instance_Class.GetMethod("LerpUnclamped").Invoke<Quaternion>(new IntPtr[]
            {
                new IntPtr((void*)(&a)),
                new IntPtr((void*)(&b)),
                new IntPtr((void*)(&t))
            }).GetValue();
        }

        // Token: 0x06000648 RID: 1608 RVA: 0x00017AD4 File Offset: 0x00015CD4
        public static Quaternion RotateTowards(Quaternion from, Quaternion to, float maxDegreesDelta)
        {
            float num = Quaternion.Angle(from, to);
            Quaternion result;
            if (num == 0f)
            {
                result = to;
            }
            else
            {
                float t = Mathf.Min(1f, maxDegreesDelta / num);
                result = Quaternion.SlerpUnclamped(from, to, t);
            }
            return result;
        }

        // Token: 0x06000649 RID: 1609 RVA: 0x00017B0D File Offset: 0x00015D0D
        public unsafe static Quaternion Inverse(Quaternion rotation)
        {
            return Quaternion.Instance_Class.GetMethod("Inverse").Invoke<Quaternion>(new IntPtr[]
            {
                new IntPtr((void*)(&rotation))
            }).GetValue();
        }

        // Token: 0x17000176 RID: 374
        // (get) Token: 0x0600064A RID: 1610 RVA: 0x00017B39 File Offset: 0x00015D39
        // (set) Token: 0x0600064B RID: 1611 RVA: 0x00017B55 File Offset: 0x00015D55
        public Vector3 eulerAngles
        {
            get
            {
                return Quaternion.Internal_MakePositive(Quaternion.Internal_ToEulerRad(this) * 57.29578f);
            }
            set
            {
                this = Quaternion.Internal_FromEulerRad(value * 0.017453292f);
            }
        }

        // Token: 0x0600064C RID: 1612 RVA: 0x00017B6D File Offset: 0x00015D6D
        public static Quaternion Euler(float x, float y, float z)
        {
            return Quaternion.Internal_FromEulerRad(new Vector3(x, y, z) * 0.017453292f);
        }

        // Token: 0x0600064D RID: 1613 RVA: 0x00017B86 File Offset: 0x00015D86
        public static Quaternion Euler(Vector3 euler)
        {
            return Quaternion.Internal_FromEulerRad(euler * 0.017453292f);
        }

        // Token: 0x0600064E RID: 1614 RVA: 0x00017B98 File Offset: 0x00015D98
        private unsafe static Quaternion Internal_FromEulerRad(Vector3 euler)
        {
            return Quaternion.Instance_Class.GetMethod("Internal_FromEulerRad").Invoke<Quaternion>(new IntPtr[]
            {
                new IntPtr((void*)(&euler))
            }).GetValue();
        }

        // Token: 0x0600064F RID: 1615 RVA: 0x00017BC4 File Offset: 0x00015DC4
        private unsafe static Vector3 Internal_ToEulerRad(Quaternion rotation)
        {
            return Quaternion.Instance_Class.GetMethod("Internal_ToEulerRad").Invoke<Vector3>(new IntPtr[]
            {
                new IntPtr((void*)(&rotation))
            }).GetValue();
        }

        // Token: 0x06000650 RID: 1616 RVA: 0x00017BF0 File Offset: 0x00015DF0
        [Obsolete("Use Quaternion.Euler instead. This function was deprecated because it uses radians instead of degrees")]
        public static Quaternion EulerRotation(float x, float y, float z)
        {
            return Quaternion.Internal_FromEulerRad(new Vector3(x, y, z));
        }

        // Token: 0x06000651 RID: 1617 RVA: 0x00017BFF File Offset: 0x00015DFF
        [Obsolete("Use Quaternion.Euler instead. This function was deprecated because it uses radians instead of degrees")]
        public static Quaternion EulerRotation(Vector3 euler)
        {
            return Quaternion.Internal_FromEulerRad(euler);
        }

        // Token: 0x06000652 RID: 1618 RVA: 0x00017C07 File Offset: 0x00015E07
        [Obsolete("Use Quaternion.Euler instead. This function was deprecated because it uses radians instead of degrees")]
        public void SetEulerRotation(float x, float y, float z)
        {
            this = Quaternion.Internal_FromEulerRad(new Vector3(x, y, z));
        }

        // Token: 0x06000653 RID: 1619 RVA: 0x00017C1C File Offset: 0x00015E1C
        [Obsolete("Use Quaternion.Euler instead. This function was deprecated because it uses radians instead of degrees")]
        public void SetEulerRotation(Vector3 euler)
        {
            this = Quaternion.Internal_FromEulerRad(euler);
        }

        // Token: 0x06000654 RID: 1620 RVA: 0x00017C2A File Offset: 0x00015E2A
        [Obsolete("Use Quaternion.eulerAngles instead. This function was deprecated because it uses radians instead of degrees")]
        public Vector3 ToEuler()
        {
            return Quaternion.Internal_ToEulerRad(this);
        }

        // Token: 0x06000655 RID: 1621 RVA: 0x00017C37 File Offset: 0x00015E37
        [Obsolete("Use Quaternion.Euler instead. This function was deprecated because it uses radians instead of degrees")]
        public static Quaternion EulerAngles(float x, float y, float z)
        {
            return Quaternion.Internal_FromEulerRad(new Vector3(x, y, z));
        }

        // Token: 0x06000656 RID: 1622 RVA: 0x00017C46 File Offset: 0x00015E46
        [Obsolete("Use Quaternion.Euler instead. This function was deprecated because it uses radians instead of degrees")]
        public static Quaternion EulerAngles(Vector3 euler)
        {
            return Quaternion.Internal_FromEulerRad(euler);
        }

        // Token: 0x06000657 RID: 1623 RVA: 0x00017C4E File Offset: 0x00015E4E
        [Obsolete("Use Quaternion.Euler instead. This function was deprecated because it uses radians instead of degrees")]
        public void SetEulerAngles(float x, float y, float z)
        {
            this.SetEulerRotation(new Vector3(x, y, z));
        }

        // Token: 0x06000658 RID: 1624 RVA: 0x00017C5E File Offset: 0x00015E5E
        [Obsolete("Use Quaternion.Euler instead. This function was deprecated because it uses radians instead of degrees")]
        public void SetEulerAngles(Vector3 euler)
        {
            this = Quaternion.EulerRotation(euler);
        }

        // Token: 0x06000659 RID: 1625 RVA: 0x00017C6C File Offset: 0x00015E6C
        [Obsolete("Use Quaternion.eulerAngles instead. This function was deprecated because it uses radians instead of degrees")]
        public static Vector3 ToEulerAngles(Quaternion rotation)
        {
            return Quaternion.Internal_ToEulerRad(rotation);
        }

        // Token: 0x0600065A RID: 1626 RVA: 0x00017C74 File Offset: 0x00015E74
        [Obsolete("Use Quaternion.eulerAngles instead. This function was deprecated because it uses radians instead of degrees")]
        public Vector3 ToEulerAngles()
        {
            return Quaternion.Internal_ToEulerRad(this);
        }

        // Token: 0x17000177 RID: 375
        public float this[int index]
        {
            get
            {
                float result;
                switch (index)
                {
                    case 0:
                        result = this.x;
                        break;
                    case 1:
                        result = this.y;
                        break;
                    case 2:
                        result = this.z;
                        break;
                    case 3:
                        result = this.w;
                        break;
                    default:
                        throw new IndexOutOfRangeException("Invalid Quaternion index!");
                }
                return result;
            }
            set
            {
                switch (index)
                {
                    case 0:
                        this.x = value;
                        return;
                    case 1:
                        this.y = value;
                        return;
                    case 2:
                        this.z = value;
                        return;
                    case 3:
                        this.w = value;
                        return;
                    default:
                        throw new IndexOutOfRangeException("Invalid Quaternion index!");
                }
            }
        }

        // Token: 0x0600065D RID: 1629 RVA: 0x00017D2B File Offset: 0x00015F2B
        public void Set(float newX, float newY, float newZ, float newW)
        {
            this.x = newX;
            this.y = newY;
            this.z = newZ;
            this.w = newW;
        }

        // Token: 0x17000178 RID: 376
        // (get) Token: 0x0600065E RID: 1630 RVA: 0x00017D4A File Offset: 0x00015F4A
        public static Quaternion identity
        {
            get
            {
                return Quaternion.identityQuaternion;
            }
        }

        // Token: 0x0600065F RID: 1631 RVA: 0x00017D54 File Offset: 0x00015F54
        public static Quaternion operator *(Quaternion lhs, Quaternion rhs)
        {
            return new Quaternion(lhs.w * rhs.x + lhs.x * rhs.w + lhs.y * rhs.z - lhs.z * rhs.y, lhs.w * rhs.y + lhs.y * rhs.w + lhs.z * rhs.x - lhs.x * rhs.z, lhs.w * rhs.z + lhs.z * rhs.w + lhs.x * rhs.y - lhs.y * rhs.x, lhs.w * rhs.w - lhs.x * rhs.x - lhs.y * rhs.y - lhs.z * rhs.z);
        }

        // Token: 0x06000660 RID: 1632 RVA: 0x00017E44 File Offset: 0x00016044
        public static Vector3 operator *(Quaternion rotation, Vector3 point)
        {
            float num = rotation.x * 2f;
            float num2 = rotation.y * 2f;
            float num3 = rotation.z * 2f;
            float num4 = rotation.x * num;
            float num5 = rotation.y * num2;
            float num6 = rotation.z * num3;
            float num7 = rotation.x * num2;
            float num8 = rotation.x * num3;
            float num9 = rotation.y * num3;
            float num10 = rotation.w * num;
            float num11 = rotation.w * num2;
            float num12 = rotation.w * num3;
            Vector3 result;
            result.x = (1f - (num5 + num6)) * point.x + (num7 - num12) * point.y + (num8 + num11) * point.z;
            result.y = (num7 + num12) * point.x + (1f - (num4 + num6)) * point.y + (num9 - num10) * point.z;
            result.z = (num8 - num11) * point.x + (num9 + num10) * point.y + (1f - (num4 + num5)) * point.z;
            return result;
        }

        // Token: 0x06000661 RID: 1633 RVA: 0x00017F6A File Offset: 0x0001616A
        public static bool operator ==(Quaternion lhs, Quaternion rhs)
        {
            return Quaternion.Dot(lhs, rhs) > 0.999999f;
        }

        // Token: 0x06000662 RID: 1634 RVA: 0x00017F7A File Offset: 0x0001617A
        public static bool operator !=(Quaternion lhs, Quaternion rhs)
        {
            return !(lhs == rhs);
        }

        // Token: 0x06000663 RID: 1635 RVA: 0x00017F86 File Offset: 0x00016186
        public static float Dot(Quaternion a, Quaternion b)
        {
            return a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w;
        }

        // Token: 0x06000664 RID: 1636 RVA: 0x00017FC0 File Offset: 0x000161C0
        public void SetLookRotation(Vector3 view)
        {
            Vector3 up = Vector3.up;
            this.SetLookRotation(view, up);
        }

        // Token: 0x06000665 RID: 1637 RVA: 0x00017FDB File Offset: 0x000161DB
        public void SetLookRotation(Vector3 view, [DefaultValue("Vector3.up")] Vector3 up)
        {
            this = Quaternion.LookRotation(view, up);
        }

        // Token: 0x06000666 RID: 1638 RVA: 0x00017FEA File Offset: 0x000161EA
        public static float Angle(Quaternion a, Quaternion b)
        {
            return Mathf.Acos(Mathf.Min(Mathf.Abs(Quaternion.Dot(a, b)), 1f)) * 2f * 57.29578f;
        }

        // Token: 0x06000667 RID: 1639 RVA: 0x00018014 File Offset: 0x00016214
        private static Vector3 Internal_MakePositive(Vector3 euler)
        {
            float num = -0.005729578f;
            float num2 = 360f + num;
            if (euler.x < num)
            {
                euler.x += 360f;
            }
            else if (euler.x > num2)
            {
                euler.x -= 360f;
            }
            if (euler.y < num)
            {
                euler.y += 360f;
            }
            else if (euler.y > num2)
            {
                euler.y -= 360f;
            }
            if (euler.z < num)
            {
                euler.z += 360f;
            }
            else if (euler.z > num2)
            {
                euler.z -= 360f;
            }
            return euler;
        }

        // Token: 0x06000668 RID: 1640 RVA: 0x000180CC File Offset: 0x000162CC
        public override int GetHashCode()
        {
            return this.x.GetHashCode() ^ this.y.GetHashCode() << 2 ^ this.z.GetHashCode() >> 2 ^ this.w.GetHashCode() >> 1;
        }

        // Token: 0x06000669 RID: 1641 RVA: 0x00018104 File Offset: 0x00016304
        public override bool Equals(object other)
        {
            bool result;
            if (!(other is Quaternion))
            {
                result = false;
            }
            else
            {
                Quaternion quaternion = (Quaternion)other;
                result = (this.x.Equals(quaternion.x) && this.y.Equals(quaternion.y) && this.z.Equals(quaternion.z) && this.w.Equals(quaternion.w));
            }
            return result;
        }

        // Token: 0x0600066A RID: 1642 RVA: 0x00018174 File Offset: 0x00016374
        public override string ToString()
        {
            return UnityString.Format("({0:F1}, {1:F1}, {2:F1}, {3:F1})", new object[]
            {
                this.x,
                this.y,
                this.z,
                this.w
            });
        }

        // Token: 0x0600066B RID: 1643 RVA: 0x000181CC File Offset: 0x000163CC
        public string ToString(string format)
        {
            return UnityString.Format("({0}, {1}, {2}, {3})", new object[]
            {
                this.x.ToString(format),
                this.y.ToString(format),
                this.z.ToString(format),
                this.w.ToString(format)
            });
        }

        // Token: 0x04000506 RID: 1286
        public float x;

        // Token: 0x04000507 RID: 1287
        public float y;

        // Token: 0x04000508 RID: 1288
        public float z;

        // Token: 0x04000509 RID: 1289
        public float w;

        // Token: 0x0400050A RID: 1290
        private static readonly Quaternion identityQuaternion = new Quaternion(0f, 0f, 0f, 1f);

        // Token: 0x0400050B RID: 1291
        public const float kEpsilon = 1E-06f;

        // Token: 0x0400050C RID: 1292
        public static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.CoreModule"].GetClass("Quaternion", "UnityEngine");
    }
}
