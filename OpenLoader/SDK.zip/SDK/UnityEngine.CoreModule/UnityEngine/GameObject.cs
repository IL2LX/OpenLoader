using System;
using IL2CPP_Core.Objects;
using UnityEngine.SceneManagement;

namespace UnityEngine
{
    public sealed class GameObject : Object
    {
        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.CoreModule"].GetClass(nameof(GameObject), "UnityEngine");

        public static unsafe GameObject CreatePrimitive(PrimitiveType type)
        {
            return Instance_Class.GetMethod(nameof(CreatePrimitive)).Invoke(new IntPtr[1]
            {
                new IntPtr((void*) &type)
            })?.GetValue<GameObject>();
        }

        public T GetComponent<T>() where T : Component
        {
            Component component = this.GetComponent(typeof(T));
            return component == null ? default(T) : component.GetValue<T>();
        }

        public Component GetComponent(System.Type type)
        {
            IL2Method method = Instance_Class.GetMethod(nameof(GetComponent), (Func<IL2Method, bool>)(x => x.GetParameters().Length == 1 && x.GetParameters()[0].ReturnType.Name == typeof(System.Type).FullName));
            IntPtr[] paramtbl = new IntPtr[1];
            IL2Object il2Object = type.ToIL2Object();
            paramtbl[0] = (object)il2Object != null ? il2Object.Pointer : IntPtr.Zero;
            return method.Invoke((IL2Object)this, paramtbl)?.GetValue<Component>();
        }

        public Component GetComponent(string type)
        {
            return Instance_Class.GetMethod(nameof(GetComponent), (Func<IL2Method, bool>)(x => x.GetParameters().Length == 1 && x.GetParameters()[0].ReturnType.Name == typeof(string).FullName)).Invoke((IL2Object)this, new IntPtr[1]
            {
                new IL2String_utf8(type).Pointer
            })?.GetValue<Component>();
        }

        public unsafe Component GetComponentInChildren(System.Type type, bool includeInactive = false)
        {
            IL2Method method = Instance_Class.GetMethod(nameof(GetComponentInChildren), (Func<IL2Method, bool>)(x => x.GetParameters().Length == 2));
            IntPtr[] paramtbl = new IntPtr[2];
            IL2Object il2Object = type.ToIL2Object();
            paramtbl[0] = (object)il2Object != null ? il2Object.Pointer : IntPtr.Zero;
            paramtbl[1] = new IntPtr((void*)&includeInactive);
            return method.Invoke((IL2Object)this, paramtbl)?.GetValue<Component>();
        }

        public T GetComponentInChildren<T>(bool includeInactive = false) where T : Component
        {
            Component componentInChildren = this.GetComponentInChildren(typeof(T), includeInactive);
            return componentInChildren == null ? default(T) : componentInChildren.GetValue<T>();
        }

        public Component GetComponentInParent(System.Type type)
        {
            IL2Method method = Instance_Class.GetMethod(nameof(GetComponentInParent), (Func<IL2Method, bool>)(x => x.GetParameters().Length == 1));
            IntPtr[] paramtbl = new IntPtr[1];
            IL2Object il2Object = type.ToIL2Object();
            paramtbl[0] = (object)il2Object != null ? il2Object.Pointer : IntPtr.Zero;
            return method.Invoke((IL2Object)this, paramtbl)?.GetValue<Component>();
        }

        public T GetComponentInParent<T>() where T : Component
        {
            Component componentInParent = this.GetComponentInParent(typeof(T));
            return componentInParent == null ? default(T) : componentInParent.GetValue<T>();
        }

        public Component[] GetComponents(System.Type type)
        {
            IL2Method method = Instance_Class.GetMethod(nameof(GetComponents), (Func<IL2Method, bool>)(x => x.GetParameters().Length == 1 && x.ReturnType.Name.EndsWith("[]")));
            IntPtr[] paramtbl = new IntPtr[1];
            IL2Object il2Object1 = type.ToIL2Object();
            paramtbl[0] = (object)il2Object1 != null ? il2Object1.Pointer : IntPtr.Zero;
            IL2Object il2Object2 = method.Invoke((IL2Object)this, paramtbl);
            return il2Object2 == (IL2Object)null ? (Component[])null : new IL2Array<IntPtr>(il2Object2.Pointer).ToArray<Component>();
        }

        public T[] GetComponents<T>() where T : Component
        {
            IL2Method method = Instance_Class.GetMethod(nameof(GetComponents), (Func<IL2Method, bool>)(x => x.GetParameters().Length == 1 && x.ReturnType.Name.EndsWith("[]")));
            IntPtr[] paramtbl = new IntPtr[1];
            IL2Object il2Object1 = typeof(T).ToIL2Object();
            paramtbl[0] = (object)il2Object1 != null ? il2Object1.Pointer : IntPtr.Zero;
            IL2Object il2Object2 = method.Invoke((IL2Object)this, paramtbl);
            return il2Object2 == (IL2Object)null ? (T[])null : new IL2Array<IntPtr>(il2Object2.Pointer).ToArray<T>();
        }

        public unsafe Component[] GetComponentsInChildren(System.Type type, bool includeInactive = false)
        {
            IL2Method method = Instance_Class.GetMethod(nameof(GetComponentsInChildren), (Func<IL2Method, bool>)(x => x.GetParameters().Length == 2 && x.ReturnType.Name.EndsWith("[]")));
            IntPtr[] paramtbl = new IntPtr[2];
            IL2Object il2Object1 = type.ToIL2Object();
            paramtbl[0] = (object)il2Object1 != null ? il2Object1.Pointer : IntPtr.Zero;
            paramtbl[1] = new IntPtr((void*)&includeInactive);
            IL2Object il2Object2 = method.Invoke((IL2Object)this, paramtbl);
            return il2Object2 == (IL2Object)null ? (Component[])null : new IL2Array<IntPtr>(il2Object2.Pointer).ToArray<Component>();
        }

        public unsafe T[] GetComponentsInChildren<T>(bool includeInactive = false) where T : Component
        {
            IL2Method method = Instance_Class.GetMethod(nameof(GetComponentsInChildren), (Func<IL2Method, bool>)(x => x.GetParameters().Length == 2 && x.ReturnType.Name.EndsWith("[]")));
            IntPtr[] paramtbl = new IntPtr[2];
            IL2Object il2Object1 = typeof(T).ToIL2Object();
            paramtbl[0] = (object)il2Object1 != null ? il2Object1.Pointer : IntPtr.Zero;
            paramtbl[1] = new IntPtr((void*)&includeInactive);
            IL2Object il2Object2 = method.Invoke((IL2Object)this, paramtbl);
            return il2Object2 == (IL2Object)null ? (T[])null : new IL2Array<IntPtr>(il2Object2.Pointer).ToArray<T>();
        }

        public static GameObject FindWithTag(string tag)
        {
            return Instance_Class.GetMethod(nameof(FindWithTag)).Invoke(new IntPtr[1]
            {
                new IL2String_utf8(tag).Pointer
            })?.GetValue<GameObject>();
        }

        public Component GetOrAddComponent(System.Type type)
        {
            Component orAddComponent = this.GetComponent(type);
            if ((IL2Object)orAddComponent == (IL2Object)null)
                orAddComponent = this.AddComponent(type);
            return orAddComponent;
        }

        public T GetOrAddComponent<T>() where T : Component
        {
            Component component = this.GetComponent(typeof(T));
            if ((IL2Object)component == (IL2Object)null)
                component = this.AddComponent(typeof(T));
            return component == null ? default(T) : component.GetValue<T>();
        }

        public Component AddComponent(System.Type type)
        {
            IL2Method method = Instance_Class.GetMethod(nameof(AddComponent), (Func<IL2Method, bool>)(m => m.GetParameters().Length == 1));
            IntPtr[] paramtbl = new IntPtr[1];
            IL2Object il2Object = type.ToIL2Object();
            paramtbl[0] = (object)il2Object != null ? il2Object.Pointer : IntPtr.Zero;
            return method.Invoke((IL2Object)this, paramtbl)?.GetValue<Component>();
        }

        public T AddComponent<T>() where T : Component
        {
            Component component = this.AddComponent(typeof(T));
            return component == null ? default(T) : component.GetValue<T>();
        }

        public Transform transform
        {
            get
            {
                return Instance_Class.GetProperty(nameof(transform)).GetGetMethod().Invoke((IL2Object)this)?.GetValue<Transform>();
            }
        }

        public unsafe int layer
        {
            get
            {
                return Instance_Class.GetProperty(nameof(layer)).GetGetMethod().Invoke<int>((IL2Object)this).GetValue();
            }
            set
            {
                Instance_Class.GetProperty(nameof(layer)).GetSetMethod().Invoke((IL2Object)this, new IntPtr[1]
                {
                    new IntPtr((void*) &value)
                });
            }
        }

        public unsafe bool active
        {
            get
            {
                return Instance_Class.GetProperty(nameof(active)).GetGetMethod().Invoke<bool>((IL2Object)this).GetValue();
            }
            set
            {
                Instance_Class.GetProperty(nameof(active)).GetSetMethod().Invoke((IL2Object)this, new IntPtr[1]
                {
                    new IntPtr((void*) &value)
                });
            }
        }

        public unsafe void SetActive(bool value)
        {
            Instance_Class.GetMethod(nameof(SetActive)).Invoke((IL2Object)this, new IntPtr[1]
            {
                new IntPtr((void*) &value)
            });
        }

        public bool activeSelf
        {
            get
            {
                return Instance_Class.GetProperty(nameof(activeSelf)).GetGetMethod().Invoke<bool>((IL2Object)this).GetValue();
            }
        }

        public bool activeInHierarchy
        {
            get
            {
                return Instance_Class.GetProperty(nameof(activeInHierarchy)).GetGetMethod().Invoke<bool>((IL2Object)this).GetValue();
            }
        }

        [Obsolete]
        public unsafe void SetActiveRecursively(bool value)
        {
            Instance_Class.GetMethod(nameof(SetActiveRecursively)).Invoke((IL2Object)this, new IntPtr[1]
            {
                new IntPtr((void*) &value)
            });
        }

        public unsafe bool isStatic
        {
            get
            {
                return Instance_Class.GetProperty(nameof(isStatic)).GetGetMethod().Invoke<bool>((IL2Object)this).GetValue();
            }
            set
            {
                Instance_Class.GetProperty(nameof(isStatic)).GetSetMethod().Invoke((IL2Object)this, new IntPtr[1]
                {
                    new IntPtr((void*) &value)
                });
            }
        }

        public string tag
        {
            get
            {
                return Instance_Class.GetProperty(nameof(tag)).GetGetMethod().Invoke((IL2Object)this)?.GetValue<IL2String>().ToString();
            }
            set
            {
                Instance_Class.GetProperty(nameof(tag)).GetSetMethod().Invoke((IL2Object)this, new IntPtr[1]
                {
                    new IL2String_utf8(value).Pointer
                });
            }
        }

        public bool CompareTag(string tag)
        {
            return Instance_Class.GetMethod(nameof(CompareTag)).Invoke<bool>((IL2Object)this, new IntPtr[1]
            {
                new IL2String_utf8(tag).Pointer
            }).GetValue();
        }

        public static GameObject FindGameObjectWithTag(string tag)
        {
            return Instance_Class.GetMethod(nameof(FindGameObjectWithTag)).Invoke(new IntPtr[1]
            {
                new IL2String_utf8(tag).Pointer
            })?.GetValue<GameObject>();
        }

        public static GameObject[] FindGameObjectsWithTag(string tag)
        {
            IL2Object il2Object = Instance_Class.GetMethod(nameof(FindGameObjectsWithTag)).Invoke(new IntPtr[1]
            {
                new IL2String_utf8(tag).Pointer
            });
            return il2Object == (IL2Object)null ? (GameObject[])null : new IL2Array<IntPtr>(il2Object.Pointer).ToArray<GameObject>();
        }

        public GameObject(IntPtr ptr): base(ptr)
        {
        }

        public GameObject(string name): base(IntPtr.Zero)
        {
            this.Pointer = Import.Object.il2cpp_object_new(GameObject.Instance_Class.Pointer);
            Instance_Class.GetMethod(".ctor", (Func<IL2Method, bool>)(x => x.GetParameters().Length == 1)).Invoke(this.Pointer, new IntPtr[1]
            {
                new IL2String_utf8(name).Pointer
            });
        }

        public GameObject(): base(IntPtr.Zero)
        {
            this.Pointer = Import.Object.il2cpp_object_new(Instance_Class.Pointer);
            Instance_Class.GetMethod(".ctor", (Func<IL2Method, bool>)(x => x.GetParameters().Length == 0)).Invoke(this.Pointer);
        }

        public GameObject(string name, params System.Type[] components) : base(IntPtr.Zero)
        {
            IL2Array<IntPtr> il2Array1 = (IL2Array<IntPtr>)null;
            if (components != null)
            {
                int length = components.Length;
                il2Array1 = new IL2Array<IntPtr>(length, IL2Type.Instance_Class);
                for (int index1 = 0; index1 < length; ++index1)
                {
                    IL2Array<IntPtr> il2Array2 = il2Array1;
                    int index2 = index1;
                    IL2Object il2Object = components[index1].ToIL2Object();
                    IntPtr num = (object)il2Object != null ? il2Object.Pointer : IntPtr.Zero;
                    il2Array2[index2] = num;
                }
            }
            this.Pointer = Import.Object.il2cpp_object_new(Instance_Class.Pointer);
            Instance_Class.GetMethod(".ctor", (Func<IL2Method, bool>)(x => x.GetParameters().Length == 2)).Invoke(this.Pointer, new IntPtr[2]
            {
                new IL2String_utf8(name).Pointer,
                il2Array1 != null ? il2Array1.Pointer : IntPtr.Zero
            });
        }

        public static GameObject Find(string name)
        {
            return Instance_Class.GetMethod(nameof(Find)).Invoke(new IntPtr[1]
            {
                new IL2String_utf8(name).Pointer
            })?.GetValue<GameObject>();
        }

        public Scene scene
        {
            get
            {
                return Instance_Class.GetProperty(nameof(scene)).GetGetMethod().Invoke<Scene>((IL2Object)this).GetValue();
            }
        }

        public ulong sceneCullingMask
        {
            get
            {
                return Instance_Class.GetProperty(nameof(sceneCullingMask)).GetGetMethod().Invoke<ulong>((IL2Object)this).GetValue();
            }
        }

        public GameObject gameObject
        {
            get
            {
                return Instance_Class.GetProperty(nameof(gameObject)).GetGetMethod().Invoke((IL2Object)this)?.GetValue<GameObject>();
            }
        }
    }
}