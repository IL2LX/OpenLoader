﻿using System;
using IL2CPP_Core.Objects;

namespace UnityEngine
{
    public class MonoBehaviour : Behaviour
    {
        public MonoBehaviour(IntPtr ptr) : base(ptr)
        {
        }

        public bool IsInvoking()
        {
            return Instance_Class.GetMethod("IsInvoking", (IL2Method x) => x.GetParameters().Length == 0).Invoke<bool>(this, true).GetValue();
        }

        public void CancelInvoke()
        {
            Instance_Class.GetMethod("CancelInvoke", (IL2Method x) => x.GetParameters().Length == 0).Invoke(this, true);
        }

        public unsafe void Invoke(string methodName, float time)
        {
            Instance_Class.GetMethod("Invoke").Invoke(this, new IntPtr[]
            {
                new IL2String_utf8(methodName).Pointer,
                new IntPtr((void*)(&time))
            }, true);
        }

        public unsafe void InvokeRepeating(string methodName, float time, float repeatRate)
        {
            Instance_Class.GetMethod("InvokeRepeating").Invoke(this, new IntPtr[]
            {
                new IL2String_utf8(methodName).Pointer,
                new IntPtr((void*)(&time)),
                new IntPtr((void*)(&repeatRate))
            }, true);
        }

        public void CancelInvoke(string methodName)
        {
            Instance_Class.GetMethod("CancelInvoke", (IL2Method x) => x.GetParameters().Length == 1).Invoke(this, new IntPtr[]
            {
                new IL2String_utf8(methodName).Pointer
            }, true);
        }

        public bool IsInvoking(string methodName)
        {
            return Instance_Class.GetMethod("IsInvoking", (IL2Method x) => x.GetParameters().Length == 1).Invoke<bool>(this, new IntPtr[]
            {
                new IL2String_utf8(methodName).Pointer
            }, true).GetValue();
        }

        public void StopAllCoroutines()
        {
            Instance_Class.GetMethod("StopAllCoroutines").Invoke(this, true);
        }

        public unsafe bool useGUILayout
        {
            get
            {
                return Instance_Class.GetProperty("useGUILayout").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("useGUILayout").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public static void print(IL2Object message)
        {
            Instance_Class.GetMethod("print").Invoke(new IntPtr[]
            {
                (message != null) ? message.Pointer : IntPtr.Zero
            });
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.CoreModule"].GetClass("MonoBehaviour", "UnityEngine");
    }
}
