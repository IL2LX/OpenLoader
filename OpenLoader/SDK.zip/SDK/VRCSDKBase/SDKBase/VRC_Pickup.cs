﻿using IL2CPP_Core.Objects;
using System;
using UnityEngine;

namespace VRC.SDKBase
{
    public class VRC_Pickup : VRCNetworkBehaviour
    {
        public VRC_Pickup(IntPtr ptr) : base(ptr)
        {
        }

        public VRCPlayerApi currentPlayer
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("currentPlayer").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<VRCPlayerApi>();
            }
        }

        public bool IsHeld
        {
            get
            {
                return Instance_Class.GetProperty("IsHeld").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public PickupHand currentHand
        {
            get
            {
                return Instance_Class.GetProperty("currentHand").GetGetMethod().Invoke<PickupHand>(this, true).GetValue();
            }
        }

        public void Drop()
        {
            Instance_Class.GetMethod("Drop", (IL2Method x) => x.GetParameters().Length == 0).Invoke(this, true);
        }

        public void Drop(VRCPlayerApi instigator)
        {
            Instance_Class.GetMethod("Drop", (IL2Method x) => x.GetParameters().Length == 1).Invoke(this, new IntPtr[]
            {
                (instigator != null) ? instigator.Pointer : IntPtr.Zero
            }, true);
        }

        public unsafe void GenerateHapticEvent(float duration = 0.25f, float amplitude = 0.5f, float frequency = 0.5f)
        {
            Instance_Class.GetMethod("GenerateHapticEvent").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&duration)),
                new IntPtr((void*)(&amplitude)),
                new IntPtr((void*)(&frequency))
            }, true);
        }

        public void PlayHaptics()
        {
            Instance_Class.GetMethod("PlayHaptics").Invoke(this, true);
        }

        public bool DisallowTheft
        {
            get
            {
                return Instance_Class.GetField("DisallowTheft").GetValue<bool>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("DisallowTheft").SetValue<bool>(this, value);
            }
        }

        public Transform ExactGun
        {
            get
            {
                IL2Object value = Instance_Class.GetField("ExactGun").GetValue(this);
                if (value == null)
                {
                    return null;
                }
                return value.GetValue<Transform>();
            }
            set
            {
                Instance_Class.GetField("ExactGun").SetValue(this, (value != null) ? value.Pointer : IntPtr.Zero);
            }
        }

        public Transform ExactGrip
        {
            get
            {
                IL2Object value = Instance_Class.GetField("ExactGrip").GetValue(this);
                if (value == null)
                {
                    return null;
                }
                return value.GetValue<Transform>();
            }
            set
            {
                Instance_Class.GetField("ExactGrip").SetValue(this, (value != null) ? value.Pointer : IntPtr.Zero);
            }
        }

        public bool allowManipulationWhenEquipped
        {
            get
            {
                return Instance_Class.GetField("allowManipulationWhenEquipped").GetValue<bool>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("allowManipulationWhenEquipped").SetValue<bool>(this, value);
            }
        }

        public PickupOrientation orientation
        {
            get
            {
                return Instance_Class.GetField("orientation").GetValue<PickupOrientation>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("orientation").SetValue<PickupOrientation>(this, value);
            }
        }

        public AutoHoldMode AutoHold
        {
            get
            {
                return Instance_Class.GetField("AutoHold").GetValue<AutoHoldMode>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("AutoHold").SetValue<AutoHoldMode>(this, value);
            }
        }

        public string InteractionText
        {
            get
            {
                IL2Object value = Instance_Class.GetField("InteractionText").GetValue(this);
                if (value == null)
                {
                    return null;
                }
                return value.GetValue<IL2String>().ToString();
            }
            set
            {
                Instance_Class.GetField("InteractionText").SetValue(this, new IL2String_utf8(value).Pointer);
            }
        }

        public string UseText
        {
            get
            {
                IL2Object value = Instance_Class.GetField("UseText").GetValue(this);
                if (value == null)
                {
                    return null;
                }
                return value.GetValue<IL2String>().ToString();
            }
            set
            {
                Instance_Class.GetField("UseText").SetValue(this, new IL2String_utf8(value).Pointer);
            }
        }

        [Obsolete("Please use a VRC_Trigger", false)]
        public VRC_EventHandler.VrcBroadcastType useEventBroadcastType
        {
            get
            {
                return Instance_Class.GetField("useEventBroadcastType").GetValue<VRC_EventHandler.VrcBroadcastType>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("useEventBroadcastType").SetValue<VRC_EventHandler.VrcBroadcastType>(this, value);
            }
        }

        [Obsolete("Please use a VRC_Trigger", false)]
        public string UseDownEventName
        {
            get
            {
                IL2Object value = Instance_Class.GetField("UseDownEventName").GetValue(this);
                if (value == null)
                {
                    return null;
                }
                return value.GetValue<IL2String>().ToString();
            }
            set
            {
                Instance_Class.GetField("UseDownEventName").SetValue(this, new IL2String_utf8(value).Pointer);
            }
        }

        [Obsolete("Please use a VRC_Trigger", false)]
        public string UseUpEventName
        {
            get
            {
                IL2Object value = Instance_Class.GetField("UseUpEventName").GetValue(this);
                if (value == null)
                {
                    return null;
                }
                return value.GetValue<IL2String>().ToString();
            }
            set
            {
                Instance_Class.GetField("UseUpEventName").SetValue(this, new IL2String_utf8(value).Pointer);
            }
        }

        [Obsolete("Please use a VRC_Trigger", false)]
        public VRC_EventHandler.VrcBroadcastType pickupDropEventBroadcastType
        {
            get
            {
                return Instance_Class.GetField("pickupDropEventBroadcastType").GetValue<VRC_EventHandler.VrcBroadcastType>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("pickupDropEventBroadcastType").SetValue<VRC_EventHandler.VrcBroadcastType>(this, value);
            }
        }

        [Obsolete("Please use a VRC_Trigger", false)]
        public string PickupEventName
        {
            get
            {
                IL2Object value = Instance_Class.GetField("PickupEventName").GetValue(this);
                if (value == null)
                {
                    return null;
                }
                return value.GetValue<IL2String>().ToString();
            }
            set
            {
                Instance_Class.GetField("PickupEventName").SetValue(this, new IL2String_utf8(value).Pointer);
            }
        }

        [Obsolete("Please use a VRC_Trigger", false)]
        public string DropEventName
        {
            get
            {
                IL2Object value = Instance_Class.GetField("DropEventName").GetValue(this);
                if (value == null)
                {
                    return null;
                }
                return value.GetValue<IL2String>().ToString();
            }
            set
            {
                Instance_Class.GetField("DropEventName").SetValue(this, new IL2String_utf8(value).Pointer);
            }
        }

        public float ThrowVelocityBoostMinSpeed
        {
            get
            {
                return Instance_Class.GetField("ThrowVelocityBoostMinSpeed").GetValue<float>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("ThrowVelocityBoostMinSpeed").SetValue<float>(this, value);
            }
        }

        public float ThrowVelocityBoostScale
        {
            get
            {
                return Instance_Class.GetField("ThrowVelocityBoostScale").GetValue<float>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("ThrowVelocityBoostScale").SetValue<float>(this, value);
            }
        }

        public VRCPlayerApi currentLocalPlayer
        {
            get
            {
                IL2Object value = Instance_Class.GetField("currentLocalPlayer").GetValue(this);
                if (value == null)
                {
                    return null;
                }
                return value.GetValue<VRCPlayerApi>();
            }
            set
            {
                Instance_Class.GetField("currentLocalPlayer").SetValue(this, (value != null) ? value.Pointer : IntPtr.Zero);
            }
        }

        public bool pickupable
        {
            get
            {
                return Instance_Class.GetField("pickupable").GetValue<bool>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("pickupable").SetValue<bool>(this, value);
            }
        }

        public float proximity
        {
            get
            {
                return Instance_Class.GetField("proximity").GetValue<float>(this).GetValue();
            }
            set
            {
                Instance_Class.GetField("proximity").SetValue<float>(this, value);
            }
        }


        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["VRCSDKBase"].GetClass("VRC_Pickup", "VRC.SDKBase");

        public enum PickupOrientation
        {
            Any,
            Grip,
            Gun
        }

        public enum AutoHoldMode
        {
            AutoDetect,
            Yes,
            No
        }

        public enum PickupHand
        {
            None,
            Left,
            Right
        }
    }
}
