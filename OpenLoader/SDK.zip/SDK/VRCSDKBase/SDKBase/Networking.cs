﻿using System;
using IL2CPP_Core.Objects;
using UnityEngine;

namespace VRC.SDKBase
{
	public static class Networking
    {
        public static VRC_EventHandler SceneEventHandler
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("SceneEventHandler").GetGetMethod().Invoke();
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<VRC_EventHandler>();
            }
        }

        public static bool IsNetworkSettled
        {
            get
            {
                return Instance_Class.GetProperty("IsNetworkSettled").GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static bool IsMaster
        {
            get
            {
                return Instance_Class.GetProperty("IsMaster").GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static bool IsClogged
        {
            get
            {
                return Instance_Class.GetProperty("IsClogged").GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static bool IsInstanceOwner
        {
            get
            {
                return Instance_Class.GetProperty("IsInstanceOwner").GetGetMethod().Invoke<bool>().GetValue();
            }
        }

        public static VRCPlayerApi GetOwner(GameObject obj)
		{
			return Instance_Class.GetMethod(nameof(GetOwner)).Invoke(new IntPtr[] { obj == null ? IntPtr.Zero : obj.Pointer })?.GetValue<VRCPlayerApi>();
		}

		public static void SetOwner(VRCPlayerApi player, GameObject obj)
		{
			Instance_Class.GetMethod(nameof(SetOwner)).Invoke(new IntPtr[] { player == null ? IntPtr.Zero : player.Pointer, obj == null ? IntPtr.Zero : obj.Pointer });
		}

        public static bool IsOwner(VRCPlayerApi player, GameObject obj)
        {
            return Instance_Class.GetMethod("IsOwner", (IL2Method x) => x.GetParameters().Length == 2).Invoke<bool>(new IntPtr[]
            {
                (player != null) ? player.Pointer : IntPtr.Zero,
                (obj != null) ? obj.Pointer : IntPtr.Zero
            }).GetValue();
        }

        public static bool IsOwner(GameObject obj)
        {
            return Instance_Class.GetMethod("IsOwner", (IL2Method x) => x.GetParameters().Length == 1).Invoke<bool>(new IntPtr[]
            {
                (obj != null) ? obj.Pointer : IntPtr.Zero
            }).GetValue();
        }

        public static bool IsObjectReady(GameObject obj)
        {
            return Instance_Class.GetMethod("IsObjectReady").Invoke<bool>(new IntPtr[]
            {
                (obj != null) ? obj.Pointer : IntPtr.Zero
            }).GetValue();
        }

        public static void Destroy(GameObject obj)
        {
            Instance_Class.GetMethod("Destroy").Invoke(new IntPtr[]
            {
                (obj != null) ? obj.Pointer : IntPtr.Zero
            });
        }

        public static string GetUniqueName(GameObject obj)
        {
            IL2Object il2Object = Instance_Class.GetMethod("GetUniqueName").Invoke(new IntPtr[]
            {
                (obj != null) ? obj.Pointer : IntPtr.Zero
            });
            if (il2Object == null)
            {
                return null;
            }
            return il2Object.GetValue<IL2String>().ToString();
        }

        public static DateTime GetNetworkDateTime()
        {
            return Instance_Class.GetMethod("GetNetworkDateTime").Invoke<DateTime>().GetValue();
        }

        public static double GetServerTimeInSeconds()
        {
            return Instance_Class.GetMethod("GetServerTimeInSeconds").Invoke<double>().GetValue();
        }

        public static int GetServerTimeInMilliseconds()
        {
            return Instance_Class.GetMethod("GetServerTimeInMilliseconds").Invoke<int>().GetValue();
        }

        public unsafe static double CalculateServerDeltaTime(double timeInSeconds, double previousTimeInSeconds)
        {
            return Instance_Class.GetMethod("CalculateServerDeltaTime").Invoke<double>(new IntPtr[]
            {
                new IntPtr((void*)(&timeInSeconds)),
                new IntPtr((void*)(&previousTimeInSeconds))
            }).GetValue();
        }

        public static VRCPlayerApi LocalPlayer
		{
			get => Instance_Class.GetProperty(nameof(LocalPlayer)).GetGetMethod().Invoke()?.GetValue<VRCPlayerApi>();
		}

        public enum SyncType
        {
            Unknown,
            None,
            Continuous,
            Manual
        }
        
        public static IL2Class Instance_Class = IL2CPP.AssemblyList["VRCSDKBase"].GetClass("Networking", "VRC.SDKBase");
	}
}
