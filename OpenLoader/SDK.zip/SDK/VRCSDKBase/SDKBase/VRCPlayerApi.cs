﻿using System;
using IL2CPP_Core.Objects;
using UnityEngine;

namespace VRC.SDKBase
{
	public class VRCPlayerApi : IL2Object
	{
		public VRCPlayerApi(IntPtr ptr) : base(ptr) { }

        public bool isMaster
        {
            get
            {
                return Instance_Class.GetProperty("isMaster").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public bool isInstanceOwner
        {
            get
            {
                return Instance_Class.GetProperty("isInstanceOwner").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public bool isModerator
        {
            get
            {
                return Instance_Class.GetProperty("isModerator").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public bool isSuper
        {
            get
            {
                return Instance_Class.GetProperty("isSuper").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public int playerId
        {
            get
            {
                return Instance_Class.GetProperty("playerId").GetGetMethod().Invoke<int>(this, true).GetValue();
            }
        }

        public bool isLocal
        {
            get
            {
                return Instance_Class.GetField("isLocal").GetValue<bool>(this).GetValue();
            }
        }

        public string displayName
        {
            get
            {
                IL2Object value = Instance_Class.GetField("displayName").GetValue(this);
                if (value == null)
                {
                    return null;
                }
                return value.GetValue<IL2String>().ToString();
            }
            set
            {
                Instance_Class.GetField("displayName").SetValue(this, new IL2String_utf8(value).Pointer);
            }
        }


        public GameObject gameObject
        {
            get
            {
                IL2Object value = Instance_Class.GetField("gameObject").GetValue(this);
                if (value == null)
                {
                    return null;
                }
                return value.GetValue<GameObject>();
            }
            set
            {
                Instance_Class.GetField("gameObject").SetValue(this, (value != null) ? value.Pointer : IntPtr.Zero);
            }
        }

        unsafe public void SetVelocity(Vector3 motion)
		{
			Instance_Class.GetMethod(nameof(SetVelocity)).Invoke(this, new IntPtr[] { new IntPtr(&motion) });
		}

        unsafe public void TeleportTo(Vector3 teleportPos, Quaternion teleportRot)
        {
            IntPtr posPtr = new IntPtr(&teleportPos);
            IntPtr rotPtr = new IntPtr(&teleportRot);
            Instance_Class.GetMethod(nameof(TeleportTo)).Invoke(this, new IntPtr[] { posPtr, rotPtr });
        }

        unsafe public void SetJumpImpulse(float impulse = 3f)
		{
			Instance_Class.GetMethod(nameof(SetJumpImpulse)).Invoke(this, new IntPtr[] { new IntPtr(&impulse) });
		}

        public float GetJumpImpulse()
        {
            return Instance_Class.GetMethod("GetJumpImpulse").Invoke<float>(this, true).GetValue();
        }

        public bool IsUserInVR()
        {
            return Instance_Class.GetMethod("IsUserInVR").Invoke<bool>(this, true).GetValue();
        }

        unsafe public void SetWalkSpeed(float speed = 2f)
        {
            Instance_Class.GetMethod(nameof(SetWalkSpeed)).Invoke(this, new IntPtr[] { new IntPtr(&speed) });
        }

        unsafe public void SetRunSpeed(float speed = 4f)
        {
            Instance_Class.GetMethod(nameof(SetRunSpeed)).Invoke(this, new IntPtr[] { new IntPtr(&speed) });
        }

        unsafe public void SetStrafeSpeed(float speed = 2f)
        {
            Instance_Class.GetMethod(nameof(SetStrafeSpeed)).Invoke(this, new IntPtr[] { new IntPtr(&speed) });
        }

        public bool IsPlayerGrounded()
        {
            return Instance_Class.GetMethod("IsPlayerGrounded").Invoke<bool>(this, true).GetValue();
        }

        public Vector3 GetVelocity()
        {
            return Instance_Class.GetMethod("GetVelocity").Invoke<Vector3>(this, true).GetValue();
        }

        public static int GetPlayerCount()
        {
            return Instance_Class.GetMethod("GetPlayerCount").Invoke<int>().GetValue();
        }

        public static int GetPlayerId(VRCPlayerApi player)
        {
            return Instance_Class.GetMethod("GetPlayerId").Invoke<int>(new IntPtr[]
            {
                (player != null) ? player.Pointer : IntPtr.Zero
            }).GetValue();
        }

        public static VRCPlayerApi GetPlayerByGameObject(GameObject playerGameObject)
        {
            IL2Object il2Object = Instance_Class.GetMethod("GetPlayerByGameObject").Invoke(new IntPtr[]
            {
                (playerGameObject != null) ? playerGameObject.Pointer : IntPtr.Zero
            });
            if (il2Object == null)
            {
                return null;
            }
            return il2Object.GetValue<VRCPlayerApi>();
        }

        public unsafe static VRCPlayerApi GetPlayerById(int playerId)
        {
            IL2Object il2Object = Instance_Class.GetMethod("GetPlayerById").Invoke(new IntPtr[]
            {
                new IntPtr((void*)(&playerId))
            });
            if (il2Object == null)
            {
                return null;
            }
            return il2Object.GetValue<VRCPlayerApi>();
        }

        public bool IsValid()
        {
            return Instance_Class.GetMethod("IsValid").Invoke<bool>(this, true).GetValue();
        }

        public bool IsOwner(GameObject obj)
        {
            return Instance_Class.GetMethod("IsOwner").Invoke<bool>(this, new IntPtr[]
            {
                (obj != null) ? obj.Pointer : IntPtr.Zero
            }, true).GetValue();
        }

        public void TakeOwnership(GameObject obj)
        {
            Instance_Class.GetMethod("TakeOwnership").Invoke(this, new IntPtr[]
            {
                (obj != null) ? obj.Pointer : IntPtr.Zero
            }, true);
        }

        public unsafe TrackingData GetTrackingData(TrackingDataType tt)
        {
            return Instance_Class.GetMethod("GetTrackingData").Invoke<TrackingData>(this, new IntPtr[]
            {
                new IntPtr((void*)(&tt))
            }, true).GetValue();
        }

        public unsafe Transform GetBoneTransform(HumanBodyBones tt)
        {
            IL2Object il2Object = Instance_Class.GetMethod("GetBoneTransform").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&tt))
            }, true);
            if (il2Object == null)
            {
                return null;
            }
            return il2Object.GetValue<Transform>();
        }

        public unsafe Vector3 GetBonePosition(HumanBodyBones tt)
        {
            return Instance_Class.GetMethod("GetBonePosition").Invoke<Vector3>(this, new IntPtr[]
            {
                new IntPtr((void*)(&tt))
            }, true).GetValue();
        }

        public unsafe Quaternion GetBoneRotation(HumanBodyBones tt)
        {
            return Instance_Class.GetMethod("GetBoneRotation").Invoke<Quaternion>(this, new IntPtr[]
            {
                new IntPtr((void*)(&tt))
            }, true).GetValue();
        }

        public unsafe VRC_Pickup GetPickupInHand(VRC_Pickup.PickupHand hand)
        {
            IL2Object il2Object = Instance_Class.GetMethod("GetPickupInHand").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&hand))
            }, true);
            if (il2Object == null)
            {
                return null;
            }
            return il2Object.GetValue<VRC_Pickup>();
        }

        public unsafe void SetPickupInHand(VRC_Pickup pickup, VRC_Pickup.PickupHand hand)
        {
            Instance_Class.GetMethod("SetPickupInHand").Invoke(this, new IntPtr[]
            {
                (pickup != null) ? pickup.Pointer : IntPtr.Zero,
                new IntPtr((void*)(&hand))
            }, true);
        }

        public unsafe void PlayHapticEventInHand(VRC_Pickup.PickupHand hand, float duration, float amplitude, float frequency)
        {
            Instance_Class.GetMethod("PlayHapticEventInHand").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&hand)),
                new IntPtr((void*)(&duration)),
                new IntPtr((void*)(&amplitude)),
                new IntPtr((void*)(&frequency))
            }, true);
        }

        public void Respawn()
        {
            Instance_Class.GetMethod("Respawn", (IL2Method x) => x.GetParameters().Length == 0).Invoke(this, true);
        }

        public unsafe void Respawn(int spawnsIndex)
        {
            Instance_Class.GetMethod("Respawn", (IL2Method x) => x.GetParameters().Length == 1).Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&spawnsIndex))
            }, true);
        }

        public unsafe void EnablePickups(bool enable)
        {
            Instance_Class.GetMethod("EnablePickups").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&enable))
            }, true);
        }

        public float GetGravityStrength()
        {
            return Instance_Class.GetMethod("GetGravityStrength").Invoke<float>(this, true).GetValue();
        }

        public unsafe void SetGravityStrength(float strength = 1f)
        {
            Instance_Class.GetMethod("SetGravityStrength").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&strength))
            }, true);
        }

        public void UseLegacyLocomotion()
        {
            Instance_Class.GetMethod("UseLegacyLocomotion").Invoke(this, true);
        }

        public unsafe void SetVoiceGain(float gain)
        {
            Instance_Class.GetMethod("SetVoiceGain").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&gain))
            }, true);
        }

        public unsafe void SetVoiceDistanceNear(float near)
        {
            Instance_Class.GetMethod("SetVoiceDistanceNear").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&near))
            }, true);
        }

        public unsafe void SetVoiceDistanceFar(float far)
        {
            Instance_Class.GetMethod("SetVoiceDistanceFar").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&far))
            }, true);
        }

        public unsafe void SetVoiceVolumetricRadius(float radius)
        {
            Instance_Class.GetMethod("SetVoiceVolumetricRadius").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&radius))
            }, true);
        }

        public unsafe void SetVoiceLowpass(bool enabled)
        {
            Instance_Class.GetMethod("SetVoiceLowpass").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&enabled))
            }, true);
        }

        public unsafe void SetAvatarAudioGain(float gain)
        {
            Instance_Class.GetMethod("SetAvatarAudioGain").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&gain))
            }, true);
        }

        public unsafe void SetAvatarAudioFarRadius(float distance)
        {
            Instance_Class.GetMethod("SetAvatarAudioFarRadius").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&distance))
            }, true);
        }

        public unsafe void SetAvatarAudioNearRadius(float distance)
        {
            Instance_Class.GetMethod("SetAvatarAudioNearRadius").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&distance))
            }, true);
        }

        public unsafe void SetAvatarAudioVolumetricRadius(float radius)
        {
            Instance_Class.GetMethod("SetAvatarAudioVolumetricRadius").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&radius))
            }, true);
        }

        public unsafe void SetAvatarAudioForceSpatial(bool force)
        {
            Instance_Class.GetMethod("SetAvatarAudioForceSpatial").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&force))
            }, true);
        }

        public unsafe void SetAvatarAudioCustomCurve(bool allow)
        {
            Instance_Class.GetMethod("SetAvatarAudioCustomCurve").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&allow))
            }, true);
        }

        public static string[] GetAvailableLanguages()
        {
            IL2Object il2Object = Instance_Class.GetMethod("GetAvailableLanguages").Invoke();
            if (il2Object == null)
            {
                return null;
            }
            IL2Array<IntPtr> il2Array = new IL2Array<IntPtr>(il2Object.Pointer);
            int length = il2Array.Length;
            string[] array = new string[length];
            for (int i = 0; i < length; i++)
            {
                array[i] = new IL2String(il2Array[i]).ToString();
            }
            return array;
        }

        public static string GetCurrentLanguage()
        {
            IL2Object il2Object = Instance_Class.GetMethod("GetCurrentLanguage").Invoke();
            if (il2Object == null)
            {
                return null;
            }
            return il2Object.GetValue<IL2String>().ToString();
        }

        public void PopAnimations()
        {
            Instance_Class.GetMethod("PopAnimations").Invoke(this, true);
        }

        public unsafe void Immobilize(bool immobile)
        {
            Instance_Class.GetMethod("Immobilize").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&immobile))
            }, true);
        }

        public Vector3 GetPosition()
        {
            return Instance_Class.GetMethod("GetPosition").Invoke<Vector3>(this, true).GetValue();
        }

        public Quaternion GetRotation()
        {
            return Instance_Class.GetMethod("GetRotation").Invoke<Quaternion>(this, true).GetValue();
        }

        public float GetAvatarEyeHeightAsMeters()
        {
            return Instance_Class.GetMethod("GetAvatarEyeHeightAsMeters").Invoke<float>(this, true).GetValue();
        }

        public float GetAvatarEyeHeightMaximumAsMeters()
        {
            return Instance_Class.GetMethod("GetAvatarEyeHeightMaximumAsMeters").Invoke<float>(this, true).GetValue();
        }

        public float GetAvatarEyeHeightMinimumAsMeters()
        {
            return Instance_Class.GetMethod("GetAvatarEyeHeightMinimumAsMeters").Invoke<float>(this, true).GetValue();
        }

        public bool GetManualAvatarScalingAllowed()
        {
            return Instance_Class.GetMethod("GetManualAvatarScalingAllowed").Invoke<bool>(this, true).GetValue();
        }

        public unsafe void SetAvatarEyeHeightByMeters(float scaleMeters)
        {
            Instance_Class.GetMethod("SetAvatarEyeHeightByMeters").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&scaleMeters))
            }, true);
        }

        public unsafe void SetAvatarEyeHeightByMultiplier(float scaleMultiplier)
        {
            Instance_Class.GetMethod("SetAvatarEyeHeightByMultiplier").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&scaleMultiplier))
            }, true);
        }

        public unsafe void SetAvatarEyeHeightMaximumByMeters(float scaleMeters)
        {
            Instance_Class.GetMethod("SetAvatarEyeHeightMaximumByMeters").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&scaleMeters))
            }, true);
        }

        public unsafe void SetAvatarEyeHeightMinimumByMeters(float scaleMeters)
        {
            Instance_Class.GetMethod("SetAvatarEyeHeightMinimumByMeters").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&scaleMeters))
            }, true);
        }

        public unsafe void SetManualAvatarScalingAllowed(bool enabled)
        {
            Instance_Class.GetMethod("SetManualAvatarScalingAllowed").Invoke(this, new IntPtr[]
            {
                new IntPtr((void*)(&enabled))
            }, true);
        }

        public static IL2Class Instance_Class = IL2CPP.AssemblyList["VRCSDKBase"].GetClass("VRCPlayerApi", "VRC.SDKBase");

        public enum TrackingDataType
        {
            Head,
            LeftHand,
            RightHand,
            Origin,
            AvatarRoot
        }

        public struct TrackingData
        {
            public TrackingData(Vector3 pos, Quaternion rot)
            {
                this.position = pos;
                this.rotation = rot;
            }
            public Vector3 position;
            public Quaternion rotation;
        }
    }
}
