﻿using IL2CPP_Core.Objects;
using System;

namespace UnityEngine
{
    public sealed class Event : IL2Object
    {
        public Event(IntPtr ptr) : base(ptr)
        {
        }

        public EventType rawType
        {
            get
            {
                return Instance_Class.GetProperty("rawType").GetGetMethod().Invoke<EventType>(this, true).GetValue();
            }
        }

        public unsafe Vector2 mousePosition
        {
            get
            {
                return Instance_Class.GetProperty("mousePosition").GetGetMethod().Invoke<Vector2>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("mousePosition").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public Vector2 delta
        {
            get
            {
                return Instance_Class.GetProperty("delta").GetGetMethod().Invoke<Vector2>(this, true).GetValue();
            }
        }

        public int button
        {
            get
            {
                return Instance_Class.GetProperty("button").GetGetMethod().Invoke<int>(this, true).GetValue();
            }
        }

        public float pressure
        {
            get
            {
                return Instance_Class.GetProperty("pressure").GetGetMethod().Invoke<float>(this, true).GetValue();
            }
        }

        public int clickCount
        {
            get
            {
                return Instance_Class.GetProperty("clickCount").GetGetMethod().Invoke<int>(this, true).GetValue();
            }
        }

        public unsafe char character
        {
            get
            {
                return Instance_Class.GetProperty("character").GetGetMethod().Invoke<char>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("character").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public unsafe KeyCode keyCode
        {
            get
            {
                return Instance_Class.GetProperty("keyCode").GetGetMethod().Invoke<KeyCode>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("keyCode").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public unsafe int displayIndex
        {
            get
            {
                return Instance_Class.GetProperty("displayIndex").GetGetMethod().Invoke<int>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("displayIndex").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public unsafe EventType type
        {
            get
            {
                return Instance_Class.GetProperty("type").GetGetMethod().Invoke<EventType>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("type").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public unsafe EventType GetTypeForControl(int controlID)
        {
            return Instance_Class.GetMethod("GetTypeForControl").Invoke<EventType>(this, new IntPtr[]
            {
                new IntPtr((void*)(&controlID))
            }, true).GetValue();
        }

        public void CopyFromPtr(IntPtr ptr)
        {
            Instance_Class.GetMethod("CopyFromPtr").Invoke(this, new IntPtr[]
            {
                ptr
            }, true);
        }

        public static bool PopEvent(Event outEvent)
        {
            if (outEvent == null)
            {
                throw new ArgumentNullException();
            }
            return Event.Instance_Class.GetMethod("PopEvent").Invoke<bool>(new IntPtr[]
            {
                outEvent.Pointer
            }).GetValue();
        }

        public Event() : base(IntPtr.Zero)
        {
            this.Pointer = Import.Object.il2cpp_object_new(Event.Instance_Class.Pointer);
            Event.Instance_Class.GetMethod(".ctor", (IL2Method x) => x.GetParameters().Length == 0).Invoke(this.Pointer, true);
        }

        public unsafe Event(int displayIndex) : base(IntPtr.Zero)
        {
            this.Pointer = Import.Object.il2cpp_object_new(Event.Instance_Class.Pointer);
            Instance_Class.GetMethod(".ctor", (IL2Method x) => x.GetParameters().Length == 1).Invoke(this.Pointer, new IntPtr[]
            {
                new IntPtr((void*)(&displayIndex))
            }, true);
        }

        public bool shift
        {
            get
            {
                return Instance_Class.GetProperty("shift").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public bool control
        {
            get
            {
                return Instance_Class.GetProperty("control").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public bool alt
        {
            get
            {
                return Instance_Class.GetProperty("alt").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public bool command
        {
            get
            {
                return Instance_Class.GetProperty("command").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public static Event current
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("current").GetGetMethod().Invoke();
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<Event>();
            }
            set
            {
                Instance_Class.GetProperty("current").GetSetMethod().Invoke(new IntPtr[]
                {
                    (value == null) ? IntPtr.Zero : value.Pointer
                });
            }
        }

        public bool isKey
        {
            get
            {
                return Instance_Class.GetProperty("isKey").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public bool isMouse
        {
            get
            {
                return Instance_Class.GetProperty("isMouse").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public bool isDirectManipulationDevice
        {
            get
            {
                return Instance_Class.GetProperty("isDirectManipulationDevice").GetGetMethod().Invoke<bool>(this, true).GetValue();
            }
        }

        public override int GetHashCode()
        {
            return Instance_Class.GetMethod("GetHashCode").Invoke<int>(this, true).GetValue();
        }

        public override bool Equals(object obj)
        {
            IL2Object il2Object = obj as IL2Object;
            return Instance_Class.GetMethod("Equals").Invoke<bool>(this, new IntPtr[]
            {
                (obj == null) ? IntPtr.Zero : il2Object.Pointer
            }, true).GetValue();
        }

        public override string ToString()
        {
            IL2Object il2Object = Instance_Class.GetMethod("ToString").Invoke(this, true);
            if (il2Object == null)
            {
                return null;
            }
            return il2Object.GetValue<IL2String>().ToString();
        }

        public void Use()
        {
            Instance_Class.GetMethod("Use").Invoke(this, true);
        }

        public static IL2Class Instance_Class = IL2CPP.AssemblyList["UnityEngine.IMGUIModule"].GetClass("Event", "UnityEngine");
    }
}
