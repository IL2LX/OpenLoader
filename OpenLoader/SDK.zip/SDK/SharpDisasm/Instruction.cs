﻿using System;
using System.Collections.Generic;
using SharpDisasm.Helpers;
using SharpDisasm.Udis86;

namespace SharpDisasm
{
    public class Instruction
    {
        public ulong Offset { get; private set; }

        public ulong PC { get; private set; }

        public byte[] Bytes { get; private set; }

        public ud_mnemonic_code Mnemonic { get; private set; }

        public Operand[] Operands { get; private set; }

        public int Length { get; private set; }

        public bool HasModRM
        {
            get
            {
                return this.have_modrm > 0;
            }
        }

        public byte ModRM
        {
            get
            {
                return this.modrm;
            }
        }

        public bool Error { get; private set; }

        public string ErrorMessage { get; private set; }

        internal Instruction(ref ud u, bool keepBinary)
        {
            this.Offset = u.insn_offset;
            this.PC = u.pc;
            this.Mnemonic = u.mnemonic;
            List<Operand> list = new List<Operand>(4);
            if (u.operand[0].type != ud_type.UD_NONE)
            {
                list.Add(new Operand(u.operand[0]));
                if (u.operand[1].type != ud_type.UD_NONE)
                {
                    list.Add(new Operand(u.operand[1]));
                    if (u.operand[2].type != ud_type.UD_NONE)
                    {
                        list.Add(new Operand(u.operand[2]));
                        if (u.operand[3].type != ud_type.UD_NONE)
                        {
                            list.Add(new Operand(u.operand[3]));
                        }
                    }
                }
            }
            this.Operands = list.ToArray();
            this.Length = u.inp_ctr;
            if (keepBinary)
            {
                this.Bytes = u.inp_buf.CopyToBytes(u.inp_buf_index - this.Length, this.Length);
            }
            if (u.error > 0)
            {
                this.Error = true;
                this.ErrorMessage = u.errorMessage;
            }
            else if (this.Mnemonic == ud_mnemonic_code.UD_Iinvalid)
            {
                this.Error = true;
                this.ErrorMessage = "Invalid instruction";
            }
            this.itab_entry = u.itab_entry;
            this.dis_mode = (ArchitectureMode)u.dis_mode;
            this.pfx_rex = u.pfx_rex;
            this.pfx_seg = u.pfx_seg;
            this.pfx_opr = u.pfx_opr;
            this.pfx_adr = u.pfx_adr;
            this.pfx_lock = u.pfx_lock;
            this.pfx_str = u.pfx_str;
            this.pfx_rep = u.pfx_rep;
            this.pfx_repe = u.pfx_repe;
            this.pfx_repne = u.pfx_repne;
            this.opr_mode = u.opr_mode;
            this.adr_mode = u.adr_mode;
            this.br_far = u.br_far;
            this.br_near = u.br_near;
            this.have_modrm = u.have_modrm;
            this.modrm = u.modrm;
            this.primary_opcode = u.primary_opcode;
        }

        public override string ToString()
        {
            if (Disassembler.Translator == null)
            {
                throw new ArgumentNullException("Translator", "Disassembler.Translator must be configured to use Instruction.ToString");
            }
            return Disassembler.Translator.Translate(this);
        }

        internal byte pfx_rex;

        internal byte pfx_seg;

        internal byte pfx_opr;

        internal byte pfx_adr;

        internal byte pfx_lock;

        internal byte pfx_str;

        internal byte pfx_rep;

        internal byte pfx_repe;

        internal byte pfx_repne;

        internal byte opr_mode;

        internal byte adr_mode;

        internal byte br_far;

        internal byte br_near;

        internal byte have_modrm;

        internal byte modrm;

        internal byte primary_opcode;

        public ArchitectureMode dis_mode;

        internal ud_itab_entry itab_entry;
    }
}
