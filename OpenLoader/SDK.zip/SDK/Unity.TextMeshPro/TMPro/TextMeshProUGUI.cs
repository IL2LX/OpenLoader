﻿using System;
using IL2CPP_Core.Objects;

namespace TMPro
{
    public class TextMeshProUGUI : TMP_Text
    {
        public TextMeshProUGUI(IntPtr ptr) : base(ptr)
        {
        }

        public TextMeshProUGUI() : base(IntPtr.Zero)
        {
            this.Pointer = Import.Object.il2cpp_object_new(Instance_Class.Pointer);
            Instance_Class.GetMethod(".ctor").Invoke(this.Pointer, true);
        }

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["Unity.TextMeshPro"].GetClass("TextMeshProUGUI", "TMPro");
    }
}
