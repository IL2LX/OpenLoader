﻿using System;
using System.Runtime.InteropServices;

namespace SDK.MinHook
{
    internal sealed class Hook
    {
        private Trampoline trampoline;

        public bool Enabled { get; private set; }

        public bool QueueEnabled { get; private set; }

        public IntPtr Original { get; private set; }

        public Hook(IntPtr target, IntPtr detour, MemorySlot memorySlot)
        {
            this.trampoline = new Trampoline(target, detour, memorySlot);
            this.Original = this.trampoline.Tramp;
        }

        public void Enable(bool enable = true)
        {
            long dwSize = (long)Marshal.SizeOf(typeof(Trampoline.JMPCALL_REL));
            IntPtr target = this.trampoline.Target;
            if (this.trampoline.PatchAbove)
            {
                target -= Marshal.SizeOf(typeof(Trampoline.JMPCALL_REL));
                dwSize += (long)Marshal.SizeOf(typeof(Trampoline.JMP_REL_SHORT));
            }
            Utils.MemoryProtection oldProtect;
            if (!Utils.VirtualProtect(target, (UIntPtr)(ulong)dwSize, Utils.MemoryProtection.ExecuteReadWrite, out oldProtect))
                throw new Exception("Failed to change memory protection");
            if (enable)
            {
                Trampoline.JMPCALL_REL structure = new Trampoline.JMPCALL_REL((byte)233);
                if (IntPtr.Size == 8)
                {
                    long operand = (long)this.trampoline.Relay - ((long)target + (long)Marshal.SizeOf<Trampoline.JMPCALL_REL>(structure));
                    structure.SetOperand((uint)operand);
                }
                else
                    structure.SetOperand((uint)((long)this.trampoline.Detour - ((long)target + (long)Marshal.SizeOf<Trampoline.JMPCALL_REL>(structure))));
                Marshal.StructureToPtr<Trampoline.JMPCALL_REL>(structure, target, false);
                if (this.trampoline.PatchAbove)
                    Marshal.StructureToPtr<Trampoline.JMP_REL_SHORT>(new Trampoline.JMP_REL_SHORT((byte)235, (byte)-(Marshal.SizeOf(typeof(Trampoline.JMP_REL_SHORT)) + Marshal.SizeOf<Trampoline.JMPCALL_REL>(structure))), this.trampoline.Target, false);
            }
            else if (this.trampoline.PatchAbove)
                Marshal.Copy(this.trampoline.Backup, 0, target, Marshal.SizeOf(typeof(Trampoline.JMPCALL_REL)) + Marshal.SizeOf(typeof(Trampoline.JMP_REL_SHORT)));
            else
                Marshal.Copy(this.trampoline.Backup, 0, target, Marshal.SizeOf(typeof(Trampoline.JMPCALL_REL)));
            Utils.VirtualProtect(target, (UIntPtr)(ulong)dwSize, oldProtect, out Utils.MemoryProtection _);
            Utils.FlushInstructionCache((IntPtr)(-1), target, (UIntPtr)(ulong)dwSize);
            this.Enabled = true;
        }
    }
}

