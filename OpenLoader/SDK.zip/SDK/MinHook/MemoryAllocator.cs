﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace SDK.MinHook
{
    internal sealed class MemoryAllocator : IDisposable
    {
        private static uint MEMORY_BLOCK_SIZE = 4096 /*0x1000*/;
        private static uint MAX_MEMORY_RANGE = 1073741824 /*0x40000000*/;
        private static List<MemoryBlock> memoryBlocks = new List<MemoryBlock>();

        public MemorySlot AllocateBuffer(IntPtr origin) => this.GetMemoryBlock(origin).AllocateSlot();

        private MemoryBlock GetMemoryBlock(IntPtr origin)
        {
            IntPtr minAddress = IntPtr.Zero;
            IntPtr maxAddress = IntPtr.Zero;
            MemoryBlock memoryBlock1 = (MemoryBlock)null;
            Utils.SYSTEM_INFO Info = new Utils.SYSTEM_INFO();
            Utils.GetSystemInfo(ref Info);
            if (IntPtr.Size == 8)
            {
                minAddress = Info.lpMinimumApplicationAddress;
                IntPtr num = Info.lpMaximumApplicationAddress;
                if ((ulong)(long)origin > (ulong)MemoryAllocator.MAX_MEMORY_RANGE && (ulong)(long)minAddress < (ulong)(long)origin - (ulong)MemoryAllocator.MAX_MEMORY_RANGE)
                    minAddress = (IntPtr)((long)origin - (long)MemoryAllocator.MAX_MEMORY_RANGE);
                if ((ulong)(long)num > (ulong)(long)origin + (ulong)MemoryAllocator.MAX_MEMORY_RANGE)
                    num = (IntPtr)((long)origin + (long)MemoryAllocator.MAX_MEMORY_RANGE);
                maxAddress = (IntPtr)((long)num - (long)MemoryAllocator.MEMORY_BLOCK_SIZE - 1L);
            }
            foreach (MemoryBlock memoryBlock2 in MemoryAllocator.memoryBlocks)
            {
                if ((IntPtr.Size != 8 || (ulong)(long)memoryBlock2.BaseAddress >= (ulong)(long)minAddress && (ulong)(long)memoryBlock2.BaseAddress < (ulong)(long)maxAddress) && !memoryBlock2.IsFull())
                    return memoryBlock2;
            }
            if (IntPtr.Size == 8)
            {
                IntPtr num1 = origin;
                while ((ulong)(long)num1 >= (ulong)(long)minAddress)
                {
                    num1 = this.FindPrevFreeRegion(num1, minAddress, Info.dwAllocationGranularity);
                    if (!(num1 == IntPtr.Zero))
                    {
                        IntPtr baseAddress = Utils.VirtualAlloc(num1, (IntPtr)(long)MemoryAllocator.MEMORY_BLOCK_SIZE, Utils.AllocationType.Commit | Utils.AllocationType.Reserve, Utils.MemoryProtection.ExecuteReadWrite);
                        if (baseAddress != IntPtr.Zero)
                        {
                            memoryBlock1 = new MemoryBlock(baseAddress);
                            break;
                        }
                    }
                    else
                        break;
                }
                if (memoryBlock1 == null)
                {
                    IntPtr num2 = origin;
                    while ((ulong)(long)num2 <= (ulong)(long)maxAddress)
                    {
                        num2 = this.FindNextFreeRegion(num2, maxAddress, Info.dwAllocationGranularity);
                        if (!(num2 == IntPtr.Zero))
                        {
                            IntPtr baseAddress = Utils.VirtualAlloc(num2, (IntPtr)(long)MemoryAllocator.MEMORY_BLOCK_SIZE, Utils.AllocationType.Commit | Utils.AllocationType.Reserve, Utils.MemoryProtection.ExecuteReadWrite);
                            if (baseAddress != IntPtr.Zero)
                            {
                                memoryBlock1 = new MemoryBlock(baseAddress);
                                break;
                            }
                        }
                        else
                            break;
                    }
                }
            }
            else
            {
                IntPtr baseAddress = Utils.VirtualAlloc(IntPtr.Zero, (IntPtr)(long)MemoryAllocator.MEMORY_BLOCK_SIZE, Utils.AllocationType.Commit | Utils.AllocationType.Reserve, Utils.MemoryProtection.ExecuteReadWrite);
                memoryBlock1 = !(baseAddress == IntPtr.Zero) ? new MemoryBlock(baseAddress) : throw new OutOfMemoryException("Failed to allocate new block of memory");
            }
            if (memoryBlock1 == null)
                throw new OutOfMemoryException("Failed to allocate new block of memory");
            MemoryAllocator.memoryBlocks.Add(memoryBlock1);
            return memoryBlock1;
        }

        private IntPtr FindPrevFreeRegion(IntPtr address, IntPtr minAddress, uint allocationGranularity)
        {
            Utils.MEMORY_BASIC_INFORMATION lpBuffer;
            for (IntPtr lpAddress = (IntPtr)((long)address - ((long)((ulong)(long)address % (ulong)allocationGranularity) - (long)allocationGranularity)); (ulong)(long)lpAddress >= (ulong)(long)minAddress; lpAddress = (IntPtr)((long)(ulong)lpBuffer.AllocationBase - (long)allocationGranularity))
            {
                lpBuffer = new Utils.MEMORY_BASIC_INFORMATION();
                if (Utils.VirtualQuery(lpAddress, ref lpBuffer, Marshal.SizeOf<Utils.MEMORY_BASIC_INFORMATION>(lpBuffer)) != 0)
                {
                    if (lpBuffer.State == Utils.MemoryState.Free)
                        return lpAddress;
                    if ((ulong)lpBuffer.AllocationBase < (ulong)allocationGranularity)
                        break;
                }
                else
                    break;
            }
            return IntPtr.Zero;
        }

        private IntPtr FindNextFreeRegion(IntPtr address, IntPtr maxAddress, uint allocationGranularity)
        {
            IntPtr num;
            for (IntPtr lpAddress = (IntPtr)((long)address - ((long)((ulong)(long)address % (ulong)allocationGranularity) + (long)allocationGranularity)); (ulong)(long)lpAddress <= (ulong)(long)maxAddress; lpAddress = (IntPtr)((long)num - (long)((ulong)(long)num % (ulong)allocationGranularity)))
            {
                Utils.MEMORY_BASIC_INFORMATION lpBuffer = new Utils.MEMORY_BASIC_INFORMATION();
                if (Utils.VirtualQuery(lpAddress, ref lpBuffer, Marshal.SizeOf<Utils.MEMORY_BASIC_INFORMATION>(lpBuffer)) != 0)
                {
                    if (lpBuffer.State == Utils.MemoryState.Free)
                        return lpAddress;
                    if ((ulong)lpBuffer.AllocationBase >= (ulong)allocationGranularity)
                        num = (IntPtr)((long)(IntPtr)((long)(ulong)lpBuffer.BaseAddress + (long)lpBuffer.RegionSize) + (long)(allocationGranularity - 1U));
                    else
                        break;
                }
                else
                    break;
            }
            return IntPtr.Zero;
        }

        public void Dispose()
        {
            foreach (MemoryBlock memoryBlock in MemoryAllocator.memoryBlocks)
                memoryBlock.Dispose();
            GC.SuppressFinalize((object)this);
        }
    }
}

