﻿using System;

namespace SDK.MinHook
{
    internal class MemoryBlock : IDisposable
    {
        private static readonly uint MEMORY_BLOCK_SIZE = 4096;
        private static readonly uint MEMORY_SLOT_SIZE = 64;
        private ulong freeBitMap;

        public IntPtr BaseAddress { get; private set; }

        public MemoryBlock(IntPtr baseAddress)
        {
            this.BaseAddress = baseAddress;
            this.freeBitMap = ulong.MaxValue;
        }

        ~MemoryBlock() => this.Dispose(false);

        protected void Dispose(bool disposing)
        {
            if (!(this.BaseAddress != IntPtr.Zero))
                return;
            Utils.VirtualFree(this.BaseAddress, (int)MEMORY_BLOCK_SIZE, Utils.FreeType.Release);
            this.BaseAddress = IntPtr.Zero;
        }

        public bool IsFull() => this.freeBitMap == 0UL;

        public MemorySlot AllocateSlot()
        {
            if (this.IsFull())
                throw new OutOfMemoryException("No free slots available");
            for (int index = 0; index < 64; ++index)
            {
                if (((long)(this.freeBitMap >> index) & 1L) == 1L)
                {
                    this.freeBitMap ^= (ulong)(1L << index);
                    return new MemorySlot((IntPtr)((long)this.BaseAddress + (long)index * (long)MEMORY_SLOT_SIZE), index);
                }
            }
            throw new InvalidOperationException("Unexpected memory block state");
        }

        public void FreeSlot(MemorySlot memorySlot)
        {
            if ((ulong)(long)memorySlot.Address < (ulong)(long)this.BaseAddress || (ulong)(long)memorySlot.Address >= (ulong)(long)this.BaseAddress + (ulong)MEMORY_BLOCK_SIZE)
                throw new ArgumentException("memorySlot does not belong to this block");
            this.freeBitMap |= (ulong)(1L << memorySlot.Index);
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize((object)this);
        }
    }
}
