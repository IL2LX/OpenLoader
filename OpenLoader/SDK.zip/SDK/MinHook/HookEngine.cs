﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace SDK.MinHook
{
    public sealed class HookEngine : IDisposable
    {
        private MemoryAllocator memoryAllocator = new MemoryAllocator();
        private Dictionary<Delegate, Hook> originalHookMapping = new Dictionary<Delegate, Hook>();
        private Dictionary<Delegate, Hook> detourHookMapping = new Dictionary<Delegate, Hook>();
        private List<IntPtr> suspendedThreads = new List<IntPtr>();

        public Func CreateHook<Func>(string dll, string function, Func detour) where Func : Delegate
        {
            IntPtr procAddress = Utils.GetProcAddress(Utils.GetModuleHandle(dll), function);
            return !(procAddress == IntPtr.Zero) ? this.CreateHook<Func>(procAddress, detour) : throw new EntryPointNotFoundException($"Function {function} could not be found in DLL {dll}");
        }

        public Func CreateHook<Func>(IntPtr target, Func detour) where Func : Delegate
        {
            if (target == IntPtr.Zero || (Delegate)detour == (Delegate)null)
                throw new ArgumentException("target or detour cannot be null");
            lock (this)
            {
                Hook hook = new Hook(target, Marshal.GetFunctionPointerForDelegate<Func>(detour), this.memoryAllocator.AllocateBuffer(target));
                Func forFunctionPointer = (Func)Marshal.GetDelegateForFunctionPointer(hook.Original, typeof(Func));
                this.originalHookMapping.Add((Delegate)forFunctionPointer, hook);
                this.detourHookMapping.Add((Delegate)detour, hook);
                return forFunctionPointer;
            }
        }

        public void EnableHooks()
        {
            foreach (KeyValuePair<Delegate, Hook> keyValuePair in this.originalHookMapping)
                this.EnableHook(keyValuePair.Key);
        }

        public void DisableHooks()
        {
            foreach (KeyValuePair<Delegate, Hook> keyValuePair in this.originalHookMapping)
                this.DisableHook(keyValuePair.Key);
        }

        public void EnableHook(Delegate original)
        {
            lock (this)
            {
                if (!this.originalHookMapping.ContainsKey(original))
                    throw new KeyNotFoundException("Hook not found, was this delegate create with CreateHook?");
                this.SuspendThreads();
                this.originalHookMapping[original].Enable();
                this.ResumeThreads();
            }
        }

        public void DisableHook(Delegate original)
        {
            lock (this)
            {
                if (!this.originalHookMapping.ContainsKey(original))
                    throw new KeyNotFoundException("Hook not found, was this delegate create with CreateHook?");
                this.SuspendThreads();
                this.originalHookMapping[original].Enable(false);
                this.ResumeThreads();
            }
        }

        private void SuspendThreads()
        {
            if (Debugger.IsAttached)
                return;
            foreach (ProcessThread thread in (ReadOnlyCollectionBase)Process.GetCurrentProcess().Threads)
            {
                if ((long)thread.Id != (long)Utils.GetCurrentThreadId())
                {
                    IntPtr hThread = Utils.OpenThread(Utils.ThreadAccess.SUSPEND_RESUME, false, (uint)thread.Id);
                    Utils.SuspendThread(hThread);
                    this.suspendedThreads.Add(hThread);
                }
            }
        }

        private void ResumeThreads()
        {
            foreach (IntPtr suspendedThread in this.suspendedThreads)
            {
                int num = (int)Utils.ResumeThread(suspendedThread);
                Utils.CloseHandle(suspendedThread);
            }
            this.suspendedThreads.Clear();
        }

        public void Dispose()
        {
            this.DisableHooks();
            this.memoryAllocator.Dispose();
            GC.SuppressFinalize((object)this);
        }
    }
}
