﻿using SharpDisasm;
using SharpDisasm.Udis86;
using System;
using System.Runtime.InteropServices;

namespace SDK.MinHook
{
    internal sealed class Trampoline
    {
        public int TrampolineMaxSize = 32 /*0x20*/;
        private static readonly int PAGE_EXECUTE = 16 /*0x10*/;
        private static readonly int PAGE_EXECUTE_READ = 32 /*0x20*/;
        private static readonly int PAGE_EXECUTE_READWRITE = 64 /*0x40*/;
        private static readonly int PAGE_EXECUTE_WRITECOPY = 128 /*0x80*/;
        private static readonly int PAGE_EXECUTE_FLAGS = PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
        private readonly MemorySlot memorySlot;

        public IntPtr Target { get; private set; }

        public IntPtr Detour { get; private set; }

        public IntPtr Tramp { get; private set; }

        public IntPtr Relay { get; private set; }

        public bool PatchAbove { get; private set; }

        public uint InstructionBoundaries { get; private set; }

        public byte[] OldInstructionBoundaries { get; private set; } = new byte[64 /*0x40*/];

        public byte[] NewInstructionBoundaries { get; private set; } = new byte[64 /*0x40*/];

        public byte[] Backup { get; private set; } = new byte[8];

        public Trampoline(IntPtr target, IntPtr detour, MemorySlot memorySlot)
        {
            this.Target = target;
            this.Detour = detour;
            this.Tramp = memorySlot.Address;
            this.memorySlot = memorySlot;
            uint srcOffset = 0;
            uint trampOffset = 0;
            IntPtr num3 = IntPtr.Zero;
            IntPtr destData = Marshal.AllocHGlobal(16 /*0x10*/);
            bool flag1 = false;
            bool is64 = IntPtr.Size == 8;
            object structureCallAbs;
            object structureJmpAbs;
            object structureJccAbsOrRel;

            if (is64)
            {
                structureCallAbs = new CALL_ABS();
                structureJmpAbs = new JMP_ABS();
                structureJccAbsOrRel = new JCC_ABS();
            }
            else
            {
                structureCallAbs = new JMPCALL_REL(0xE8); // CALL rel
                structureJmpAbs = new JMPCALL_REL(0xE9);  // JMP rel
                structureJccAbsOrRel = new JCC_REL(0);
            }

            do
            {
                object rewriteStructure = null;
                IntPtr curSrc = (IntPtr)((long)this.Target + (long)srcOffset);
                IntPtr curDst = (IntPtr)((long)this.Tramp + (long)trampOffset);

                // disassemble from curSrc; copyBinaryToInstruction:true to get bytes/operands
                var disassembler = new Disassembler(curSrc, 16 /*max bytes to read*/, is64 ? ArchitectureMode.x86_64 : ArchitectureMode.x86_32, copyBinaryToInstruction: true);
                disassembler.Disassemble();
                Instruction instruction = disassembler.NextInstruction();
                if (instruction == null)
                    throw new Exception("Failed to disassemble instruction.");
                if (instruction.Error)
                    throw new Exception(instruction.ErrorMessage);

                IntPtr srcData = curSrc;
                uint copyLen = (uint)instruction.Length;

                // If we've already passed space needed for a relative JMPCALL/REL, emit a long jump/call instead
                if ((long)srcOffset >= Marshal.SizeOf(typeof(JMPCALL_REL)))
                {
                    // replace with absolute JMP/CALL structure (or rel structure for 32-bit)
                    if (is64)
                        ((AddressSupport)structureJmpAbs).SetAddress(curSrc);
                    else
                        ((OperandSupport)structureJmpAbs).SetOperand((uint)((ulong)(uint)(int)curSrc - ((ulong)(uint)(int)curDst + (ulong)Marshal.SizeOf(structureJmpAbs))));
                    rewriteStructure = structureJmpAbs;
                    copyLen = (uint)Marshal.SizeOf(structureJmpAbs);
                    flag1 = true;
                }
                // RIP-relative memory access on x64 (modrm & disp32)
                else if (is64 && instruction.have_modrm == 1 && ((instruction.modrm & 0xC7) == 5))
                {
                    byte reg = (byte)(((int)instruction.modrm & 0x3F) >> 3);
                    srcData = destData;
                    Utils.CopyMemory(destData, curSrc, (int)copyLen);

                    // adjust displacement inside copied instruction
                    // Find position of the 32-bit displacement inside instruction:
                    // instruction.Length - 4 ... instruction.Length - 1
                    int dispOffsetFromEnd = 4;
                    Marshal.WriteInt32((IntPtr)((long)destData + (long)instruction.Length - dispOffsetFromEnd), (int)(uint)((long)curSrc + (long)instruction.Length + (long)instruction.Operands[0].LvalUDWord - ((long)curDst + (long)instruction.Length)));
                    if (instruction.Bytes[0] == 0xFF && reg == 4)
                        flag1 = true;
                }
                else if (instruction.Mnemonic == ud_mnemonic_code.UD_Icall)
                {
                    IntPtr address = (IntPtr)((long)curSrc + (long)instruction.Length + (long)instruction.Operands[0].LvalSDWord);
                    if (is64)
                        ((AddressSupport)structureCallAbs).SetAddress(address);
                    else
                        ((OperandSupport)structureCallAbs).SetOperand((uint)((int)address - (int)(curDst + Marshal.SizeOf(structureCallAbs))));
                    rewriteStructure = structureCallAbs;
                    copyLen = (uint)Marshal.SizeOf(structureCallAbs);
                }
                else if (((instruction.Bytes[0] & 0xFD) == 0xE9) || ((instruction.Bytes[0] & 0xFD) == 0xE8))
                {
                    // jmp/call rel/opcodes
                    IntPtr next = curSrc + instruction.Length;
                    IntPtr address = instruction.Bytes[0] != 0xE9 ? IntPtr.Add(next, instruction.Operands[0].LvalSDWord) : IntPtr.Add(next, (int)instruction.Operands[0].LvalByte);
                    if ((long)this.Target <= (long)address && (long)address < (long)this.Target + Marshal.SizeOf(typeof(JMPCALL_REL)))
                    {
                        if ((long)num3 < (long)address)
                            num3 = address;
                    }
                    else
                    {
                        if (is64)
                            ((AddressSupport)structureJmpAbs).SetAddress(address);
                        else
                            ((OperandSupport)structureJmpAbs).SetOperand((uint)((ulong)(uint)(int)address - ((ulong)(uint)(int)curDst + (ulong)Marshal.SizeOf(structureJmpAbs))));
                        rewriteStructure = structureJmpAbs;
                        copyLen = (uint)Marshal.SizeOf(structureJmpAbs);
                        flag1 = (long)curSrc >= (long)num3;
                    }
                }
                else if ((instruction.Length >= 2 && ((instruction.Bytes[0] & 0xF0) == 0x70))
                    || ((instruction.Bytes[0] & 0xFC) == 0xE0)
                    || (instruction.Bytes[0] == 0xF0 && ((instruction.Bytes[1] & 0xF0) == 0x80)))
                {
                    IntPtr next = curSrc + instruction.Length;
                    IntPtr address = (((instruction.Bytes[0] & 0xF0) == 0x70) || ((instruction.Bytes[0] & 0xFC) == 0xE0))
                        ? IntPtr.Add(next, (int)instruction.Operands[0].LvalByte)
                        : IntPtr.Add(next, (int)instruction.Operands[0].LvalUDWord);

                    if ((long)this.Target <= (long)address && (long)address < (long)this.Target + Marshal.SizeOf(typeof(JMPCALL_REL)))
                    {
                        if ((long)num3 < (long)address)
                            num3 = address;
                    }
                    else
                    {
                        if (((instruction.Bytes[0] & 0xFC) == 0xE0))
                            throw new Exception("LOOPx/Jxx to the outside not supported");
                        byte num9 = (byte)((instruction.Bytes[0] != 15 ? instruction.Bytes[0] : instruction.Bytes[1]) & 0xF0);
                        if (is64)
                        {
                            ((OpcodeSupport)structureJccAbsOrRel).SetOpcode((byte)(113U ^ (uint)num9));
                            ((AddressSupport)structureJccAbsOrRel).SetAddress(address);
                        }
                        else
                        {
                            ((OpcodeSupport)structureJccAbsOrRel).SetOpcode((byte)(128U ^ (uint)num9));
                            ((OperandSupport)structureJccAbsOrRel).SetOperand((uint)((ulong)(uint)(int)address - ((ulong)(uint)(int)curDst + (ulong)Marshal.SizeOf(structureJccAbsOrRel))));
                        }
                        rewriteStructure = structureJccAbsOrRel;
                        copyLen = (uint)Marshal.SizeOf(structureJccAbsOrRel);
                    }
                }
                else if (instruction.Mnemonic == ud_mnemonic_code.UD_Iret || instruction.Mnemonic == ud_mnemonic_code.UD_Iretf)
                {
                    flag1 = (long)curSrc >= (long)num3;
                }

                if ((long)curSrc < (long)num3 && (long)copyLen != (long)instruction.Length)
                    throw new Exception("Can't alter instruction length in a branch");

                if ((long)(trampOffset + copyLen) > (long)this.TrampolineMaxSize)
                    throw new Exception("Trampoline function too big");

                if ((long)this.InstructionBoundaries > (long)this.OldInstructionBoundaries.Length)
                    throw new Exception("Trampoline has too many instructions");

                this.OldInstructionBoundaries[this.InstructionBoundaries] = (byte)srcOffset;
                this.NewInstructionBoundaries[this.InstructionBoundaries] = (byte)trampOffset;
                ++this.InstructionBoundaries;

                if (rewriteStructure != null)
                {
                    IntPtr tmp = Marshal.AllocHGlobal((int)copyLen);
                    Marshal.StructureToPtr(rewriteStructure, tmp, false);
                    Utils.CopyMemory((IntPtr)((long)this.Tramp + trampOffset), tmp, (int)copyLen);
                    Marshal.FreeHGlobal(tmp);
                }
                else
                {
                    Utils.CopyMemory((IntPtr)((long)this.Tramp + trampOffset), srcData, (int)copyLen);
                }

                trampOffset += copyLen;
                srcOffset += (uint)instruction.Length;

            } while (!flag1);

            // check for padding and potential 'patch above' scenario
            if ((long)srcOffset < Marshal.SizeOf(typeof(JMPCALL_REL)) &&
                this.IsCodePadding((IntPtr)((long)this.Target + (long)srcOffset), (int)((long)Marshal.SizeOf(typeof(JMPCALL_REL)) - (long)srcOffset)))
            {
                if ((long)srcOffset < Marshal.SizeOf(typeof(JMP_REL_SHORT)) &&
                    this.IsCodePadding((IntPtr)((long)this.Target + (long)srcOffset), (int)((long)Marshal.SizeOf(typeof(JMP_REL_SHORT)) - (long)srcOffset)))
                    throw new Exception("Not enough space for patch");
                if (!this.IsExecutableAddress((IntPtr)((long)this.Target - Marshal.SizeOf(typeof(JMPCALL_REL)))))
                    throw new Exception("Not enought space for patch");
                if (!this.IsCodePadding((IntPtr)((long)this.Target - Marshal.SizeOf(typeof(JMPCALL_REL))), Marshal.SizeOf(typeof(JMPCALL_REL))))
                    throw new Exception("Not enought space for patch");
                this.PatchAbove = true;
            }

            if (is64)
            {
                ((AddressSupport)structureJmpAbs).SetAddress(this.Detour);
                this.Relay = (IntPtr)((long)this.Tramp + (long)trampOffset);
                IntPtr buf = Marshal.AllocHGlobal(Marshal.SizeOf(structureJmpAbs));
                Marshal.StructureToPtr(structureJmpAbs, buf, false);
                Utils.CopyMemory(this.Relay, buf, Marshal.SizeOf(structureJmpAbs));
                Marshal.FreeHGlobal(buf);
            }

            Marshal.FreeHGlobal(destData);
            this.BackupPrologue();
        }

        private void BackupPrologue()
        {
            if (this.PatchAbove)
            {
                int len = Marshal.SizeOf(typeof(JMPCALL_REL)) + Marshal.SizeOf(typeof(JMP_REL_SHORT));
                Marshal.Copy((IntPtr)((long)this.Target - Marshal.SizeOf(typeof(JMPCALL_REL))), this.Backup, 0, len);
            }
            else
            {
                Marshal.Copy(this.Target, this.Backup, 0, Marshal.SizeOf(typeof(JMPCALL_REL)));
            }
        }

        private bool IsExecutableAddress(IntPtr address)
        {
            Utils.MEMORY_BASIC_INFORMATION lpBuffer = new Utils.MEMORY_BASIC_INFORMATION();
            int size = Marshal.SizeOf(typeof(Utils.MEMORY_BASIC_INFORMATION));
            Utils.VirtualQuery(address, ref lpBuffer, size);
            return lpBuffer.State == Utils.MemoryState.Commited && ((long)lpBuffer.Protect & (long)PAGE_EXECUTE_FLAGS) > 0L;
        }

        private bool IsCodePadding(IntPtr codePtr, int len)
        {
            byte[] destination = new byte[len];
            Marshal.Copy(codePtr, destination, 0, len);
            if (destination[0] != 0 && destination[0] != 0x90 /*NOP*/ && destination[0] != 204 /*0xCC*/)
                return false;
            for (int i = 1; i < destination.Length; ++i)
            {
                if (destination[i] != destination[0])
                    return false;
            }
            return true;
        }

        // Interfaces used by runtime-rewritten instruction structs
        public interface AddressSupport
        {
            void SetAddress(IntPtr address);
        }

        public interface OperandSupport
        {
            void SetOperand(uint operand);
        }

        public interface OpcodeSupport
        {
            void SetOpcode(byte opcode);
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct JMP_REL_SHORT
        {
            public byte opcode;
            public byte operand;
            public JMP_REL_SHORT(byte op, byte oper) { opcode = op; operand = oper; }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct JMPCALL_REL : OperandSupport
        {
            public byte opcode;
            public uint operand;

            public JMPCALL_REL(byte opcode)
            {
                this.opcode = opcode;
                this.operand = 0;
            }

            public void SetOperand(uint operand) => this.operand = operand;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct JMP_ABS : AddressSupport
        {
            public byte opcode0; // 0xFF
            public byte opcode1; // 0x25
            public uint dummy;
            public ulong address; // absolute address after RIP-rel placeholder

            public void SetAddress(IntPtr address) => this.address = (ulong)(long)address;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct CALL_ABS : AddressSupport
        {
            public byte opcode0;
            public byte opcode1;
            public uint dummy0;
            public byte dummy1;
            public byte dummy2;
            public ulong address;

            public void SetAddress(IntPtr address) => this.address = (ulong)(long)address;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct JCC_REL : OperandSupport, OpcodeSupport
        {
            public byte opcode0; // 0x0F
            public byte opcode1; // 0x80 etc.
            public uint operand;

            public JCC_REL(uint operand)
            {
                opcode0 = 0x0F;
                opcode1 = 0x80;
                this.operand = operand;
            }

            public void SetOpcode(byte opcode) => this.opcode1 = opcode;

            public void SetOperand(uint operand) => this.operand = operand;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct JCC_ABS : AddressSupport, OpcodeSupport
        {
            public byte opcode; // short opcode variant for x64 mapping
            public byte dummy0;
            public byte dummy1;
            public byte dummy2;
            public uint dummy3;
            public ulong address;

            public void SetAddress(IntPtr address) => this.address = (ulong)(long)address;

            public void SetOpcode(byte opcode) => this.opcode = opcode;
        }
    }
}
