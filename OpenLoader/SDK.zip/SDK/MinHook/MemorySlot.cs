﻿using System;

namespace SDK.MinHook
{
    internal class MemorySlot
    {
        public IntPtr Address { get; private set; }

        public int Index { get; private set; }

        public MemorySlot(IntPtr address, int index)
        {
            this.Address = address;
            this.Index = index;
        }
    }
}
