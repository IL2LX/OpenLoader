﻿using System;

namespace IL2CPP_Core.Objects
{
    public class IL2ClassType : IL2Object
    {
        internal IL2ClassType(IntPtr ptr) : base(ptr) { }

        public string Name
        {
            get => Import.Object.il2cpp_type_get_name(Pointer);
        }
        public IL2Object GetObject()
        {
            IntPtr intPtr = Import.Class.il2cpp_type_get_object(this.Pointer);
            if (intPtr == IntPtr.Zero)
            {
                return null;
            }
            return new IL2Object(intPtr);
        }
    }
}
