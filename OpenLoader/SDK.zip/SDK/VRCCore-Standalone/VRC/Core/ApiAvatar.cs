﻿using System;
using IL2CPP_Core.Objects;

namespace VRC.Core
{
    public class ApiAvatar : ApiModel
    {
        public ApiAvatar(IntPtr ptr) : base(ptr) { }

        public ApiAvatar() : base(IntPtr.Zero)
        {
            Pointer = Import.Object.il2cpp_object_new(Instance_Class.Pointer);
            Instance_Class.GetMethod(".ctor").Invoke(Pointer);
        }

        public string releaseStatus
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("releaseStatus").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<IL2String>().ToString();
            }
            set
            {
                Instance_Class.GetProperty("releaseStatus").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IL2String_utf8(value).Pointer
                }, true);
            }
        }

        public string authorId
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("authorId").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<IL2String>().ToString();
            }
            set
            {
                Instance_Class.GetProperty("authorId").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IL2String_utf8(value).Pointer
                }, true);
            }
        }

        public string assetUrl
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("assetUrl").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<IL2String>().ToString();
            }
            set
            {
                Instance_Class.GetProperty("assetUrl").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IL2String_utf8(value).Pointer
                }, true);
            }
        }

        public string name
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("name").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<IL2String>().ToString();
            }
            set
            {
                Instance_Class.GetProperty("name").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IL2String_utf16(value).Pointer
                }, true);
            }
        }

        public void SaveReleaseStatus(Action<ApiContainer> onSuccess = null, Action<ApiContainer> onFailure = null)
        {
            IntPtr zero = IntPtr.Zero;
            IntPtr zero2 = IntPtr.Zero;
            Instance_Class.GetMethod("SaveReleaseStatus").Invoke(this, new IntPtr[]
            {
                zero,
                zero2
            }, true);
        }

        public static new IL2Class Instance_Class = IL2CPP.AssemblyList["VRCCore-Standalone"].GetClass("ApiAvatar", "VRC.Core");
    }
}
