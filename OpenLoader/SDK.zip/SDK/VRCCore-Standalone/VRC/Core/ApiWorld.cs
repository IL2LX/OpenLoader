﻿using IL2CPP_Core.Objects;
using System;
using System.Collections.Generic;
using System.Linq;

namespace VRC.Core
{
    public class ApiWorld : ApiModel
    {
        public ApiWorld(IntPtr ptr) : base(ptr) { }

        public static AssetVersion VERSION
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("VERSION").GetGetMethod().Invoke();
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<AssetVersion>();
            }
        }

        public bool ShouldCache()
        {
            return Instance_Class.GetMethod("ShouldCache").Invoke<bool>(this, true).GetValue();
        }

        public float GetLifeSpan()
        {
            return Instance_Class.GetMethod("GetLifeSpan").Invoke<float>(this, true).GetValue();
        }

        public string[] tags
        {
            get
            {
                IL2Property property = Instance_Class.GetProperty("tags");
                IL2Object il2Object;
                if (property == null)
                {
                    il2Object = null;
                }
                else
                {
                    IL2Method getMethod = property.GetGetMethod();
                    il2Object = ((getMethod != null) ? getMethod.Invoke(this, true) : null);
                }
                IL2Object il2Object2 = il2Object;
                if (il2Object2 == null)
                {
                    return null;
                }
                IL2ListObject<IL2String> il2ListObject = new IL2ListObject<IL2String>(il2Object2.Pointer);
                if (il2ListObject == null)
                {
                    return null;
                }
                IL2String[] array = il2ListObject.ToArray();
                if (array == null)
                {
                    return null;
                }
                IEnumerable<string> enumerable = from x in array
                                                 select x.ToString();
                if (enumerable == null)
                {
                    return null;
                }
                return enumerable.ToArray<string>();
            }
            set
            {
                IL2Object il2Object = Instance_Class.GetProperty("tags").GetGetMethod().Invoke(this, true);
                IL2ListObject<IL2String> il2ListObject = new IL2ListObject<IL2String>(il2Object.Pointer);
                il2ListObject.Clear();
                for (int i = 0; i < value.Length; i++)
                {
                    string value2 = value[i];
                    il2ListObject.Add(new IL2String_utf8(value2));
                }
                Instance_Class.GetProperty("tags").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    il2Object.Pointer
                }, true);
            }
        }

        public string name
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("name").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<IL2String>().ToString();
            }
        }

        public string imageUrl
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("imageUrl").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<IL2String>().ToString();
            }
        }

        public const float ListCacheTime = 180f;
        public const float SingleRecordCacheTime = 30f;
        public const string ADMIN_TAG_INTERNAL = "admin_internal_world";

        public new static IL2Class Instance_Class = IL2CPP.AssemblyList["VRCCore-Standalone"].GetClass("ApiWorld", "VRC.Core");

        public enum SortHeading
        {
            None,
            Featured,
            Trending,
            Updated,
            Created,
            Active,
            Recent,
            Favorite,
            Labs,
            Playlist,
            Shuffle,
            Random,
            Publication,
            Heat,
            Order,
            Relevance,
            SavedSearch,
            Name,
            Exact
        }

        public enum SortOwnership
        {
            Any,
            Mine,
            Friend
        }

        public enum SortOrder
        {
            Ascending,
            Descending
        }

        public enum ReleaseStatus
        {
            Public,
            Private,
            All,
            Hidden
        }
    }
}