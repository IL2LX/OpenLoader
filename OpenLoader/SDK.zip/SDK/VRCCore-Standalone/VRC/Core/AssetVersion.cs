﻿using System;
using IL2CPP_Core.Objects;

namespace VRC.Core
{
    public class AssetVersion : IL2Object
    {
        public AssetVersion(IntPtr ptr) : base(ptr)
        {
        }

        public string UnityVersion
        {
            get
            {
                IL2Object il2Object = Instance_Class.GetProperty("UnityVersion").GetGetMethod().Invoke(this, true);
                if (il2Object == null)
                {
                    return null;
                }
                return il2Object.GetValue<IL2String>().ToString();
            }
        }

        public unsafe int ApiVersion
        {
            get
            {
                return Instance_Class.GetProperty("ApiVersion").GetGetMethod().Invoke<int>(this, true).GetValue();
            }
            set
            {
                Instance_Class.GetProperty("ApiVersion").GetSetMethod().Invoke(this, new IntPtr[]
                {
                    new IntPtr((void*)(&value))
                }, true);
            }
        }

        public AssetVersion() : base(IntPtr.Zero)
        {
            this.Pointer = Import.Object.il2cpp_object_new(Instance_Class.Pointer);
            Instance_Class.GetMethod(".ctor", (IL2Method x) => x.GetParameters().Length == 0).Invoke(this.Pointer, true);
        }

        public unsafe AssetVersion(int apiVersion) : base(IntPtr.Zero)
        {
            this.Pointer = Import.Object.il2cpp_object_new(Instance_Class.Pointer);
            Instance_Class.GetMethod(".ctor", (IL2Method x) => x.GetParameters().Length == 1).Invoke(this.Pointer, new IntPtr[]
            {
                new IntPtr((void*)(&apiVersion))
            }, true);
        }

        public override string ToString()
        {
            IL2Object il2Object = Instance_Class.GetMethod("ToString").Invoke(this, true);
            if (il2Object == null)
            {
                return null;
            }
            return il2Object.GetValue<IL2String>().ToString();
        }

        public static IL2Class Instance_Class = IL2CPP.AssemblyList["VRCCore-Standalone"].GetClass("AssetVersion", "VRC.Core");
    }
}
